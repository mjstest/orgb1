(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"300x500_atlas_P_", frames: [[170,0,62,126],[0,0,168,76]]}
];


// symbols:



(lib._99 = function() {
	this.initialize(img._99);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,441,600);


(lib.face = function() {
	this.spriteSheet = ss["300x500_atlas_P_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.hand = function() {
	this.spriteSheet = ss["300x500_atlas_P_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1A1F71").s().p("AgGAHQgDgDAAgEQAAgDADgDQADgDADAAQAEAAADADQACADAAADQAAAEgCADQgDADgEAAQgEAAgCgDg");
	this.shape.setTransform(45.4,257.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1A1F71").s().p("AgPBBQAUgcgBglQABglgUgbIALAAQAUAbAAAlQAAAlgUAcg");
	this.shape_1.setTransform(41,253.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1A1F71").s().p("AAfA2IgMgiIgmAAIgLAiIgOAAIAlhrIAPAAIAlBrgAAQAJIgLgeIgFgTIAAAAIgFATIgKAeIAfAAg");
	this.shape_2.setTransform(34.2,252.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1A1F71").s().p("Ag3A2IAAhrIAOAAIAABgIAjAAIAAhgIANAAIAABgIAjAAIAAhgIAOAAIAABrg");
	this.shape_3.setTransform(22.5,252.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#1A1F71").s().p("AgZApQgPgOAAgaQAAgZAQgPQAPgQAYAAQARAAAJAFIgDALQgKgEgMAAQgSAAgMALQgLAMAAAUQAAAUALAMQALAMASAAQAOAAAJgFIADALQgLAGgSAAQgWAAgPgPg");
	this.shape_4.setTransform(11.2,252.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1A1F71").s().p("AAFBBQgUgcAAglQAAglAUgbIALAAQgTAbAAAlQAAAlATAcg");
	this.shape_5.setTransform(4.6,253.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1A1F71").s().p("AgPBBQAUgcgBglQABglgUgbIALAAQAUAbAAAlQAAAlgUAcg");
	this.shape_6.setTransform(254.5,231.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1A1F71").s().p("AATAnIAAgrQAAgXgSAAQgFAAgGAEQgFAFgCAFIAAAHIAAAtIgPAAIAAg3IAAgVIAMAAIABANQAEgGAGgEQAHgFAIAAQAKAAAIAHQAJAIAAASIAAAtg");
	this.shape_7.setTransform(248.1,232.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1A1F71").s().p("AgaAdQgLgLAAgSQAAgRALgMQALgLAPAAQARAAAKAMQALAKAAASQAAATgMALQgLAKgPAAQgQAAgKgLgAgRgTQgGAIAAALQAAAMAHAJQAHAIAJAAQAKAAAHgIQAGgJABgMQAAgLgGgIQgGgKgMAAQgKAAgHAKg");
	this.shape_8.setTransform(239.4,232.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1A1F71").s().p("AgGA2IAAhNIANAAIAABNgAgFgmQgDgDAAgDQAAgEADgDQACgCADAAQAEAAACACQADADAAAEQAAADgDADQgCADgEAAQgDAAgCgDg");
	this.shape_9.setTransform(233.1,230.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1A1F71").s().p("AgEAqQgGgFAAgOIAAgqIgMAAIAAgLIAMAAIAAgNIANgFIAAASIAUAAIAAALIgUAAIAAApQAAAPAKAAIAJgBIAAALQgFACgHAAQgKAAgEgHg");
	this.shape_10.setTransform(228.6,231.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1A1F71").s().p("AgYAiQgGgHAAgJQAAgOAMgGQAMgIAVAAIAAgBQAAgTgQABQgLAAgJAFIgDgJQALgHANAAQAdAAABAgIAAAcQgBAMACAGIgNAAIgBgKIgBAAQgIAMgOAAQgMAAgGgGgAgQARQAAAGAEAEQAEADAFAAQAGAAAGgEQAFgDABgGIABgFIAAgMIgCAAQgeAAAAARg");
	this.shape_11.setTransform(222,232.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#1A1F71").s().p("AgGA2IAAhNIANAAIAABNgAgFgmQgDgDAAgDQAAgEADgDQACgCADAAQAEAAACACQADADAAAEQAAADgDADQgCADgEAAQgDAAgCgDg");
	this.shape_12.setTransform(216.5,230.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#1A1F71").s().p("AgTAdQgKgLAAgSQAAgQALgMQALgMASAAQAMABAHAEIgDAKQgGgDgKAAQgMgBgHAJQgHAJAAALQAAANAHAIQAIAIAKAAQAKAAAIgEIACALQgIAEgOAAQgRAAgKgLg");
	this.shape_13.setTransform(211.1,232.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#1A1F71").s().p("AgaAdQgLgLAAgSQAAgRALgMQALgLAPAAQARAAAKAMQALAKAAASQAAATgNALQgKAKgPAAQgQAAgKgLgAgRgTQgGAIABALQgBAMAHAJQAGAIAKAAQAKAAAGgIQAIgJAAgMQgBgLgFgIQgGgKgMAAQgLAAgGAKg");
	this.shape_14.setTransform(203.1,232.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#1A1F71").s().p("AgYAjIADgLQAJAGAKgBQAGAAAEgCQAEgDAAgGQAAgFgEgDQgDgDgHgDQgUgGAAgPQAAgJAHgHQAHgHALAAQALAAAIAFIgDAKQgHgEgJAAQgFAAgDADQgEADAAAFQAAAEAEADQADACAHADQAUAIAAAPQAAAKgHAHQgIAGgNAAQgMABgJgGg");
	this.shape_15.setTransform(195.6,232.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#1A1F71").s().p("AgYAjIADgLQAJAGAKgBQAGAAAEgCQAEgDAAgGQAAgFgEgDQgDgDgHgDQgUgGAAgPQAAgJAHgHQAHgHALAAQALAAAIAFIgDAKQgHgEgJAAQgFAAgDADQgEADAAAFQAAAEAEADQADACAHADQAUAIAAAPQAAAKgHAHQgIAGgNAAQgMABgJgGg");
	this.shape_16.setTransform(189.3,232.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#1A1F71").s().p("AAfA2IgMgiIgmAAIgLAiIgOAAIAkhrIAQAAIAlBrgAAQAJIgKgeIgGgUIAAAAIgFAUIgKAeIAfAAg");
	this.shape_17.setTransform(181.3,230.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#1A1F71").s().p("AgXAdQgKgKAAgSQAAgRAKgLQAKgNAPAAQARAAAJANQAGAKAAAOIAAAFIg2AAQABAOAHAHQAHAGALAAQAMAAAJgEIADALQgLAEgPAAQgRAAgKgLgAAVgHQAAgJgEgGQgFgHgLAAQgJgBgGAIQgFAGgBAJIApAAIAAAAg");
	this.shape_18.setTransform(169,232.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#1A1F71").s().p("AgTAdQgLgLABgSQgBgQAMgMQALgMASAAQAMABAHAEIgCAKQgHgDgKAAQgLgBgIAJQgHAJAAALQAAANAHAIQAIAIAKAAQAKAAAIgEIACALQgIAEgOAAQgQAAgLgLg");
	this.shape_19.setTransform(161.5,232.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#1A1F71").s().p("AgGA2IAAhNIANAAIAABNgAgFgmQgDgDAAgDQAAgEADgDQACgCADAAQAEAAACACQADADAAAEQAAADgDADQgCADgEAAQgDAAgCgDg");
	this.shape_20.setTransform(156,230.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#1A1F71").s().p("AgGAnIgehNIAPAAIAQArIAFAUIAAAAIAHgUIAPgrIAPAAIgfBNg");
	this.shape_21.setTransform(150.4,232.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#1A1F71").s().p("AgSAnIAAg0IgBgYIANAAIABAPIAAAAQACgHAGgFQAGgFAGAAIAFABIAAANIgFAAQgHAAgGAEQgEAGgBAIIgBAHIAAAng");
	this.shape_22.setTransform(144.4,232.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#1A1F71").s().p("AgXAdQgKgKAAgSQAAgRAKgLQAKgNAPAAQARAAAJANQAGAKAAAOIAAAFIg2AAQABAOAHAHQAHAGALAAQAMAAAJgEIADALQgLAEgPAAQgRAAgKgLgAAVgHQAAgJgEgGQgFgHgLAAQgJgBgGAIQgFAGgBAJIApAAIAAAAg");
	this.shape_23.setTransform(137.3,232.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#1A1F71").s().p("AggAwIAEgLQALAHAOAAQAJAAAHgFQAFgFAAgJQAAgHgEgFQgFgFgKgEQgcgJAAgVQAAgMAJgIQAKgJAPAAQAOAAAJAFIgDAMQgKgFgLAAQgJAAgGAFQgEAEAAAHQAAAHAFAFQAFAEAKAFQAOAFAHAGQAHAIAAALQAAAOgKAIQgKAKgRAAQgRAAgLgIg");
	this.shape_24.setTransform(129.4,230.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#1A1F71").s().p("AgGA5IAAhxIANAAIAABxg");
	this.shape_25.setTransform(120.2,230.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#1A1F71").s().p("AgYAiQgGgHAAgJQAAgOAMgGQAMgIAVAAIAAgBQAAgTgQABQgLAAgJAFIgDgJQAKgHAOAAQAdAAABAgIAAAcQgBAMACAGIgNAAIgBgKIgBAAQgHAMgPAAQgLAAgHgGgAgQARQAAAGAEAEQAEADAFAAQAHAAAEgEQAGgDABgGIABgFIAAgMIgCAAQgeAAAAARg");
	this.shape_26.setTransform(114.3,232.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#1A1F71").s().p("AATAnIAAgrQAAgXgSAAQgFAAgGAEQgFAFgCAFIAAAHIAAAtIgPAAIAAg3IAAgVIAMAAIABANQAEgGAGgEQAHgFAIAAQAKAAAIAHQAJAIAAASIAAAtg");
	this.shape_27.setTransform(106.2,232.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#1A1F71").s().p("AgaAdQgLgLAAgSQAAgRALgMQALgLAPAAQARAAAKAMQALAKAAASQAAATgNALQgKAKgPAAQgQAAgKgLgAgRgTQgGAIABALQgBAMAHAJQAGAIAKAAQAKAAAGgIQAIgJAAgMQgBgLgFgIQgHgKgLAAQgLAAgGAKg");
	this.shape_28.setTransform(97.5,232.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#1A1F71").s().p("AgGA2IAAhNIANAAIAABNgAgFgmQgDgDAAgDQAAgEADgDQACgCADAAQAEAAACACQADADAAAEQAAADgDADQgCADgEAAQgDAAgCgDg");
	this.shape_29.setTransform(91.2,230.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#1A1F71").s().p("AgFAqQgFgFAAgOIAAgqIgMAAIAAgLIAMAAIAAgNIAMgFIAAASIAVAAIAAALIgVAAIAAApQAAAPALAAIAIgBIABALQgFACgHAAQgKAAgFgHg");
	this.shape_30.setTransform(86.7,231.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#1A1F71").s().p("AgYAiQgGgHAAgJQAAgOAMgGQAMgIAWAAIAAgBQAAgTgRABQgLAAgJAFIgEgJQALgHAOAAQAeAAgBAgIAAAcQABAMABAGIgNAAIgBgKIAAAAQgJAMgOAAQgMAAgGgGgAgQARQAAAGAEAEQADADAHAAQAGAAAFgEQAEgDACgGIABgFIAAgMIgCAAQgeAAAAARg");
	this.shape_31.setTransform(80.1,232.2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#1A1F71").s().p("AATAnIAAgrQAAgXgSAAQgFAAgGAEQgFAFgCAFIAAAHIAAAtIgPAAIAAg3IAAgVIAMAAIABANQAEgGAGgEQAHgFAIAAQAKAAAIAHQAJAIAAASIAAAtg");
	this.shape_32.setTransform(72,232.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#1A1F71").s().p("AgSAnIAAg0IAAgYIAMAAIAAAPIABAAQACgHAFgFQAGgFAIAAIADABIAAANIgEAAQgIAAgFAEQgEAGgBAIIgBAHIAAAng");
	this.shape_33.setTransform(65.4,232.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#1A1F71").s().p("AgXAdQgKgKAAgSQAAgRAKgLQAKgNAPAAQARAAAJANQAGAKAAAOIAAAFIg2AAQABAOAHAHQAHAGALAAQAMAAAJgEIADALQgLAEgPAAQgRAAgKgLgAAVgHQAAgJgEgGQgFgHgLAAQgJgBgGAIQgFAGgBAJIApAAIAAAAg");
	this.shape_34.setTransform(58.4,232.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#1A1F71").s().p("AgFAqQgFgFAAgOIAAgqIgMAAIAAgLIAMAAIAAgNIAMgFIAAASIAVAAIAAALIgVAAIAAApQAAAPALAAIAIgBIABALQgFACgIAAQgJAAgFgHg");
	this.shape_35.setTransform(51.7,231.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#1A1F71").s().p("AATAnIAAgrQAAgXgSAAQgFAAgGAEQgFAFgCAFIAAAHIAAAtIgPAAIAAg3IAAgVIAMAAIABANQAEgGAGgEQAHgFAIAAQAKAAAIAHQAJAIAAASIAAAtg");
	this.shape_36.setTransform(44.7,232.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#1A1F71").s().p("AgGA2IAAhrIANAAIAABrg");
	this.shape_37.setTransform(38.4,230.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#1A1F71").s().p("AgYAiQgGgHAAgJQAAgOAMgGQAMgIAWAAIAAgBQAAgTgRABQgLAAgJAFIgEgJQAMgHANAAQAeAAAAAgIAAAcQAAAMABAGIgNAAIgBgKIgBAAQgHAMgPAAQgMAAgGgGgAgQARQAAAGAEAEQAEADAGAAQAFAAAFgEQAGgDABgGIABgFIAAgMIgCAAQgeAAAAARg");
	this.shape_38.setTransform(29.1,232.2);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#1A1F71").s().p("AgYAjIADgLQAJAGAKgBQAGAAAEgCQAEgDAAgGQAAgFgEgDQgDgDgHgDQgUgGAAgPQAAgJAHgHQAHgHALAAQALAAAIAFIgDAKQgHgEgJAAQgFAAgDADQgEADAAAFQAAAEAEADQADACAHADQAUAIAAAPQAAAKgHAHQgIAGgNAAQgMABgJgGg");
	this.shape_39.setTransform(22.3,232.2);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#1A1F71").s().p("AgGA2IAAhNIANAAIAABNgAgFgmQgDgDAAgDQAAgEADgDQACgCADAAQAEAAACACQADADAAAEQAAADgDADQgCADgEAAQgDAAgCgDg");
	this.shape_40.setTransform(17.3,230.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#1A1F71").s().p("AgIA2IgkhrIAPAAIARA1IAMAnIAAAAQACgNAJgaIATg1IAPAAIgnBrg");
	this.shape_41.setTransform(11,230.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#1A1F71").s().p("AAFBBQgUgcAAglQAAglAUgbIALAAQgTAbAAAlQAAAlATAcg");
	this.shape_42.setTransform(4.6,231.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#1A1F71").s().p("AgCAeIAUgeIgUgcIAKAAIAWAcIgWAegAgcAeIAVgeIgWgcIAMAAIAVAcIgVAeg");
	this.shape_43.setTransform(235.5,210);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#1A1F71").s().p("AASAnIAAgjIgjAAIAAAjIgOAAIAAhNIAOAAIAAAgIAjAAIAAggIAOAAIAABNg");
	this.shape_44.setTransform(227.8,210.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#1A1F71").s().p("AgvAnIAAhNIAOAAIAABCIAbAAIAAhCIANAAIAABCIAbAAIAAhCIAOAAIAABNg");
	this.shape_45.setTransform(217.6,210.1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#1A1F71").s().p("AATA3IAAgiIACgeIgBAAIgNAXIgXApIgQAAIAAhNIANAAIAAAgIgBAfIABAAIAMgYIAXgnIARAAIAABNgAgUg1IAKAAQABAMAJAAQAJAAABgMIALAAQgCATgTABQgTgBgBgTg");
	this.shape_46.setTransform(207.3,208.6);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#1A1F71").s().p("AgfAjIADgKQAKAEAJAAQALAAAHgHQAIgHABgLIgmAAIAAgIIAmAAQgBgMgHgGQgHgHgLAAQgJAAgKAFIgDgJQALgHANAAQARAAAKALQALAMAAARQAAARgLAMQgLAMgSgBQgMAAgLgFg");
	this.shape_47.setTransform(199,210.2);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#1A1F71").s().p("AAUAnIAAghIABgfIgBAAIgNAYIgXAoIgQAAIAAhNIANAAIAAAhIgBAeIABAAIANgYIAXgnIAQAAIAABNg");
	this.shape_48.setTransform(191,210.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#1A1F71").s().p("AgTAeQgLgMAAgRQAAgSAMgLQAMgMARAAQALAAAJAEIgEAMQgGgFgKAAQgMAAgHAJQgHAIAAAMQAAANAHAIQAIAIALAAQAIAAAJgEIADAKQgKAGgNgBQgRABgKgLg");
	this.shape_49.setTransform(183.1,210.2);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#1A1F71").s().p("AgaAeQgLgMAAgRQAAgSAMgMQAKgLAQAAQAQAAALALQAKAMAAARQAAATgNAMQgKAKgPgBQgQABgKgLgAgRgUQgFAJAAALQAAANAGAIQAHAJAJAAQAKAAAGgJQAIgIgBgNQAAgLgFgIQgGgKgMAAQgLAAgGAJg");
	this.shape_50.setTransform(175.1,210.2);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#1A1F71").s().p("AgTAeQgLgMAAgRQAAgSAMgLQAMgMARAAQAMAAAHAEIgCAMQgHgFgKAAQgLAAgIAJQgHAIAAAMQAAANAIAIQAHAIALAAQAJAAAIgEIACAKQgJAGgNgBQgQABgLgLg");
	this.shape_51.setTransform(167.2,210.2);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#1A1F71").s().p("AgTAeQgKgMAAgRQAAgSALgLQAMgMARAAQALAAAJAEIgEAMQgGgFgKAAQgMAAgHAJQgHAIAAAMQAAANAHAIQAIAIAKAAQAJAAAJgEIADAKQgJAGgOgBQgRABgKgLg");
	this.shape_52.setTransform(160,210.2);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#1A1F71").s().p("AAeA2IgLgiIglAAIgMAiIgOAAIAlhrIAQAAIAkBrgAAQAJIgLgeIgFgTIAAAAIgFATIgLAeIAgAAg");
	this.shape_53.setTransform(151.5,208.6);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#1A1F71").s().p("AgTAeQgKgMAAgRQAAgSALgLQAMgMARAAQALAAAJAEIgEAMQgGgFgKAAQgMAAgHAJQgHAIAAAMQAAANAHAIQAIAIAKAAQAJAAAJgEIADAKQgJAGgOgBQgRABgKgLg");
	this.shape_54.setTransform(139.8,210.2);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#1A1F71").s().p("AATAnIAAghIABgfIAAAAIgNAYIgXAoIgQAAIAAhNIANAAIAAAhIAAAeIAAAAIAMgYIAYgnIAQAAIAABNg");
	this.shape_55.setTransform(131.7,210.1);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#1A1F71").s().p("AgeAnIAAhMQAKgBAOgBQAiABAAASQAAAIgFAEQgEAEgIACIAAAAQAJACAGAEQAFAFAAAHQAAAYgoAAIgVgBgAgRAdIALABQAXAAAAgOQAAgNgYAAIgKAAgAgRgdIAAAYIALAAQAUgBAAgMQAAgLgUAAg");
	this.shape_56.setTransform(123.5,210.2);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#1A1F71").s().p("AgjA3IAAhSIgBgaIAMAAIABAOQAKgPARAAQAOAAAKAKQAJALAAASQAAATgLALQgJALgPAAQgQAAgHgNIgBAAIAAAqgAgNgmQgGAEgCAIIgBAGIAAANIABAGQACAGAGAFQAGAEAHAAQAKAAAHgIQAGgHAAgNQAAgNgGgIQgGgIgLAAQgGAAgHAFg");
	this.shape_57.setTransform(115,211.6);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#1A1F71").s().p("AgXAeQgKgLAAgSQAAgRAKgMQAKgMAPAAQARAAAJANQAGAKAAAOIAAAGIg2AAQABANAHAHQAHAGALAAQAMAAAJgEIADAKQgLAGgPgBQgRABgKgLgAAVgGQAAgKgEgGQgFgIgLAAQgJABgGAHQgFAHgBAJIApAAIAAAAg");
	this.shape_58.setTransform(106.2,210.2);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#1A1F71").s().p("AgZApQgPgOAAgaQAAgZAQgPQAPgQAYAAQARAAAJAFIgDALQgKgEgMAAQgSAAgMALQgLAMAAAUQAAAUALAMQALAMASAAQAOAAAJgFIADALQgLAGgSAAQgWAAgPgPg");
	this.shape_59.setTransform(97.6,208.6);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#1A1F71").s().p("AgiAcQAFAAADgDQAFgEABgIQACgHAAgNIAAgfIA1AAIAABMIgOAAIAAhBIgaAAIAAAUQAAARgCAJQgDALgHAEQgGAFgJAAg");
	this.shape_60.setTransform(85,210.2);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#1A1F71").s().p("AASAnIAAgjIgjAAIAAAjIgOAAIAAhNIAOAAIAAAgIAjAAIAAggIAOAAIAABNg");
	this.shape_61.setTransform(77.1,210.1);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#1A1F71").s().p("AgvAnIAAhNIAOAAIAABCIAbAAIAAhCIANAAIAABCIAbAAIAAhCIAOAAIAABNg");
	this.shape_62.setTransform(66.9,210.1);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#1A1F71").s().p("AgfAjIADgKQAKAEAJAAQALAAAHgHQAIgHABgLIgmAAIAAgIIAmAAQgBgMgHgGQgHgHgLAAQgJAAgKAFIgDgJQALgHANAAQARAAAKALQALAMAAARQAAARgLAMQgLAMgSgBQgMAAgLgFg");
	this.shape_63.setTransform(57.2,210.2);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#1A1F71").s().p("AASAnIAAgjIgjAAIAAAjIgOAAIAAhNIAOAAIAAAgIAjAAIAAggIAOAAIAABNg");
	this.shape_64.setTransform(49.2,210.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#1A1F71").s().p("AgkA3IAAhSIAAgaIAMAAIABAOQAKgPARAAQAOAAAJAKQAKALAAASQAAATgLALQgJALgPAAQgPAAgIgNIAAAAIAAAqgAgMgmQgHAEgBAIIgBAGIAAANIABAGQABAGAGAFQAGAEAHAAQAKAAAHgIQAGgHAAgNQAAgNgGgIQgHgIgKAAQgHAAgFAFg");
	this.shape_65.setTransform(40.6,211.6);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#1A1F71").s().p("AgXAeQgKgLAAgSQAAgRAKgMQAKgMAPAAQARAAAJANQAGAKAAAOIAAAGIg2AAQABANAHAHQAHAGALAAQAMAAAJgEIADAKQgLAGgPgBQgRABgKgLgAAVgGQAAgKgEgGQgFgIgLAAQgJABgGAHQgFAHgBAJIApAAIAAAAg");
	this.shape_66.setTransform(31.8,210.2);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#1A1F71").s().p("AgGAnIAAhBIgYAAIAAgMIA9AAIAAAMIgYAAIAABBg");
	this.shape_67.setTransform(24.5,210.1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#1A1F71").s().p("AASAnIAAgjIgjAAIAAAjIgOAAIAAhNIAOAAIAAAgIAjAAIAAggIAOAAIAABNg");
	this.shape_68.setTransform(16.9,210.1);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#1A1F71").s().p("AAbA2IAAguQABgbABgQIgBAAQgFAOgPAVIghA2IgOAAIAAhrIANAAIAAAtQAAAagBATIAAAAQAHgOANgWIAhg2IAPAAIAABrg");
	this.shape_69.setTransform(7.3,208.6);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#1A1F71").s().p("AgYAiQgGgHAAgJQAAgOAMgGQAMgIAVAAIAAgBQAAgTgQABQgLAAgJAFIgDgJQALgHANABQAdgBABAgIAAAcQgBAMACAGIgNAAIgBgKIgBAAQgIANgOAAQgMgBgGgGgAgQARQAAAGAEAEQAEADAFAAQAGAAAGgEQAFgDABgGIABgFIAAgMIgCAAQgeAAAAARg");
	this.shape_70.setTransform(213.4,188.2);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#1A1F71").s().p("AgcAiIADgJQAKAFALAAQAIAAAFgEQAFgDAAgGQAAgOgWAAIgHAAIAAgIIAHAAQAIAAAFgEQAGgDAAgGQAAgFgEgDQgEgDgGAAQgKAAgJAFIgDgIQALgHAOAAQAKAAAHAEQAJAGAAAKQAAAHgGAFQgFAEgHACQAJABAGAEQAGAFAAAIQAAAMgKAGQgJAFgNAAQgOAAgLgGg");
	this.shape_71.setTransform(206.3,188.1);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#1A1F71").s().p("AATAnIAAghIABgfIAAAAIgNAYIgXAoIgQAAIAAhNIANAAIAAAhIAAAeIAAAAIAMgYIAYgnIAQAAIAABNg");
	this.shape_72.setTransform(198.5,188.1);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#1A1F71").s().p("AghA1IAAhpQALgCAPAAQATAAAJAIQAJAHAAAMQAAAIgFAGQgEAHgJADIAAAAQAJACAGAFQAHAIAAALQAAANgJAJQgLAKgZAAQgMAAgKgCgAgTArIAMABQALAAAHgFQAJgFAAgLQAAgLgJgFQgHgFgLAAIgMAAgAgTgqIAAAiIANAAQAKAAAGgFQAGgFAAgIQAAgRgWAAIgNABg");
	this.shape_73.setTransform(190,186.6);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#1A1F71").s().p("AASAdIgUgdIAUgcIALAAIgVAcIAVAdgAgHAdIgVgdIAVgcIAKAAIgUAcIAUAdg");
	this.shape_74.setTransform(182.1,188);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#1A1F71").s().p("AATAnIAAggIgKAAQgJAAgDAEQgDADgDAHIgFAMIgDAGIgPAAIAFgJIAEgMQAEgHAEgEQAEgEAEAAIAAgBQgIgBgFgDQgHgGAAgIQAAgLAKgGQAKgFAPAAIAZABIAABMgAgNgPQAAAHAIADQAFADAIAAIALAAIAAgaIgLgBQgVAAAAAOg");
	this.shape_75.setTransform(171,188.1);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#1A1F71").s().p("AATAnIAAghIABgfIAAAAIgNAYIgXAoIgQAAIAAhNIANAAIAAAhIAAAeIAAAAIAMgYIAXgnIARAAIAABNg");
	this.shape_76.setTransform(163.1,188.1);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#1A1F71").s().p("AAYAzIgBgZIg6AAIAAhMIAOAAIAABBIAjAAIAAhBIAOAAIAABCIAIAAIgBAjg");
	this.shape_77.setTransform(154.5,189.4);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#1A1F71").s().p("AgYAiQgGgHAAgJQAAgOAMgGQAMgIAWAAIAAgBQAAgTgRABQgLAAgJAFIgEgJQALgHAOABQAegBgBAgIAAAcQABAMABAGIgNAAIgBgKIAAAAQgJANgOAAQgMgBgGgGgAgQARQAAAGAEAEQADADAHAAQAGAAAFgEQAEgDACgGIABgFIAAgMIgCAAQgeAAAAARg");
	this.shape_78.setTransform(145.8,188.2);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#1A1F71").s().p("AgjA3IAAhSIgBgaIANAAIAAAOQAKgPARAAQAPAAAJAKQAJALAAASQAAATgLALQgKALgOAAQgQAAgHgNIgBAAIAAAqgAgNgmQgFAEgDAIIgBAGIAAANIABAGQACAGAGAFQAGAEAHAAQAKAAAGgIQAHgHAAgNQAAgNgGgIQgGgIgLAAQgGAAgHAFg");
	this.shape_79.setTransform(137.8,189.6);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#1A1F71").s().p("AgaAdQgLgKAAgTQAAgRAMgMQAKgLAPABQARAAAKALQALALAAARQAAATgMALQgLALgPAAQgQAAgKgMgAgRgTQgGAHAAAMQAAAMAHAJQAHAJAJgBQAKABAHgJQAGgJABgMQAAgLgGgIQgGgKgMAAQgKAAgHAKg");
	this.shape_80.setTransform(128.7,188.2);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#1A1F71").s().p("AASAnIAAhBIgjAAIAABBIgOAAIAAhNIA/AAIAABNg");
	this.shape_81.setTransform(120,188.1);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#1A1F71").s().p("AgkA3IAAhSIAAgaIAMAAIACAOQAJgPARAAQAPAAAIAKQAKALAAASQAAATgLALQgKALgOAAQgPAAgIgNIAAAAIAAAqgAgMgmQgHAEgBAIIgBAGIAAANIABAGQABAGAGAFQAGAEAHAAQALAAAFgIQAHgHAAgNQAAgNgGgIQgHgIgKAAQgHAAgFAFg");
	this.shape_82.setTransform(111.3,189.6);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#1A1F71").s().p("AgaAdQgLgKAAgTQAAgRAMgMQAKgLAQABQAQAAALALQAKALAAARQAAATgNALQgKALgPAAQgQAAgKgMgAgRgTQgFAHAAAMQAAAMAGAJQAHAJAJgBQAKABAGgJQAIgJgBgMQAAgLgFgIQgGgKgMAAQgLAAgGAKg");
	this.shape_83.setTransform(102.2,188.2);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#1A1F71").s().p("AAVA2IgJgaQgEgMgGgFQgHgHgMAAIgFAAIAAAyIgOAAIAAhrIAOAAIAAAwIAEAAIAkgwIARAAIgoAxQAMACAHAHQAGAGAFAMQAJAaADAFg");
	this.shape_84.setTransform(94,186.6);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#1A1F71").s().p("AgGAHQgCgDAAgEQAAgDACgDQADgDADAAQAEAAADADQADADAAADQAAAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_85.setTransform(84.3,191.2);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#1A1F71").s().p("AgpAmIAAhMIAOAAIAAAaIANgBQAOAAAIAGQAKAHAAAMQAAALgIAHQgKAJgUAAQgLAAgKgBgAgbgCIAAAeIAKABQAJAAAGgEQAGgEAAgIQAAgJgGgEQgFgDgKAAgAAcAmIAAhMIAOAAIAABMg");
	this.shape_86.setTransform(77.2,188.2);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#1A1F71").s().p("AAgAnIgDglIgBgbIgBAAIgIAZIgPAmIgJAAIgOgmIgIgZIAAAAIgBAbIgCAlIgOAAIAHhNIARAAIAOAmIAGAWIAJgaIANgiIARAAIAFBNg");
	this.shape_87.setTransform(66.8,188.1);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#1A1F71").s().p("AAfAnIgCglIgBgbIAAAAIgJAZIgPAmIgJAAIgOgmIgHgZIgBAAIgBAbIgDAlIgMAAIAGhNIARAAIAOAmIAGAWIAKgaIAMgiIARAAIAGBNg");
	this.shape_88.setTransform(56.6,188.1);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#1A1F71").s().p("AgYAiQgGgHAAgJQAAgOAMgGQAMgIAWAAIAAgBQAAgTgRABQgLAAgJAFIgEgJQAMgHANABQAdgBAAAgIAAAcQAAAMACAGIgNAAIgBgKIgBAAQgIANgOAAQgMgBgGgGgAgQARQAAAGAEAEQADADAHAAQAFAAAFgEQAFgDACgGIABgFIAAgMIgCAAQgeAAAAARg");
	this.shape_89.setTransform(47.4,188.2);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#1A1F71").s().p("AgjA3IAAhSIgBgaIAMAAIABAOQAKgPARAAQAOAAAKAKQAJALAAASQAAATgLALQgJALgPAAQgQAAgHgNIgBAAIAAAqgAgNgmQgFAEgDAIIgBAGIAAANIABAGQACAGAGAFQAGAEAHAAQAKAAAHgIQAGgHAAgNQAAgNgGgIQgGgIgLAAQgGAAgHAFg");
	this.shape_90.setTransform(39.5,189.6);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#1A1F71").s().p("AgXAnIAAhNIAvAAIAAAMIghAAIAABBg");
	this.shape_91.setTransform(32,188.1);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#1A1F71").s().p("AgaAdQgLgKAAgTQAAgRAMgMQAKgLAQABQAQAAALALQAKALAAARQAAATgMALQgLALgPAAQgQAAgKgMgAgRgTQgFAHgBAMQABAMAGAJQAHAJAJgBQAKABAHgJQAGgJAAgMQABgLgGgIQgGgKgMAAQgLAAgGAKg");
	this.shape_92.setTransform(24.2,188.2);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#1A1F71").s().p("AgkA3IAAhSIAAgaIAMAAIACAOQAJgPARAAQAPAAAIAKQAKALAAASQAAATgLALQgKALgOAAQgPAAgIgNIAAAAIAAAqgAgMgmQgHAEgBAIIgBAGIAAANIABAGQABAGAGAFQAGAEAHAAQALAAAGgIQAGgHAAgNQAAgNgGgIQgHgIgKAAQgHAAgFAFg");
	this.shape_93.setTransform(15.5,189.6);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#1A1F71").s().p("AASAnIAAhBIgjAAIAABBIgOAAIAAhNIA/AAIAABNg");
	this.shape_94.setTransform(6.4,188.1);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#1A1F71").s().p("AgeAnIAAhMQAKgBAOgBQAiABAAASQAAAIgFAEQgEAEgIACIAAAAQAJACAGAEQAFAEAAAIQAAAXgoAAIgVAAgAgRAdIALABQAXAAAAgOQAAgNgYAAIgKAAgAgRgdIAAAYIALAAQAUgBAAgLQAAgMgUAAg");
	this.shape_95.setTransform(212.9,166.2);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#1A1F71").s().p("AgaAeQgLgMAAgRQAAgTAMgLQAKgLAQAAQAQABALAKQAKAMAAARQAAATgNALQgKALgPgBQgQABgKgLgAgRgUQgFAJAAALQAAANAGAIQAHAJAJAAQAKAAAGgJQAIgIgBgNQAAgLgFgIQgGgKgMAAQgLAAgGAJg");
	this.shape_96.setTransform(204.3,166.2);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#1A1F71").s().p("AgjA3IAAhSIgBgaIAMAAIABAOQAKgPARAAQAOAAAKAKQAJALAAASQAAATgLALQgJALgPAAQgQAAgHgNIgBAAIAAAqgAgNgmQgFAEgDAIIgBAGIAAANIABAGQACAGAGAFQAGAEAHAAQAKAAAHgIQAGgHAAgNQAAgNgGgIQgGgIgLAAQgGAAgHAFg");
	this.shape_97.setTransform(195.6,167.6);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#1A1F71").s().p("AgXAeQgKgLAAgSQAAgRAKgMQAKgLAPgBQARAAAJANQAGAKAAAOIAAAGIg2AAQABANAHAHQAHAGALAAQAMAAAJgEIADALQgLAEgPAAQgRABgKgLgAAVgGQAAgJgEgHQgFgHgLgBQgJAAgGAIQgFAGgBAKIApAAIAAAAg");
	this.shape_98.setTransform(186.8,166.2);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#1A1F71").s().p("AASAnIAAgjIgjAAIAAAjIgOAAIAAhNIAOAAIAAAgIAjAAIAAggIAOAAIAABNg");
	this.shape_99.setTransform(178.5,166.1);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#1A1F71").s().p("AgGAnIAAhBIgYAAIAAgMIA9AAIAAAMIgYAAIAABBg");
	this.shape_100.setTransform(170.9,166.1);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#1A1F71").s().p("AgkA3IAAhSIAAgaIANAAIABAOQAJgPARAAQAPAAAIAKQAKALAAASQAAATgLALQgKALgOAAQgPAAgIgNIAAAAIAAAqgAgMgmQgHAEgCAIIAAAGIAAANIAAAGQACAGAGAFQAGAEAHAAQALAAAFgIQAHgHAAgNQAAgNgGgIQgHgIgKAAQgHAAgFAFg");
	this.shape_101.setTransform(163.3,167.6);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#1A1F71").s().p("AgYAhQgGgGAAgJQAAgOAMgHQAMgHAWAAIAAgCQAAgRgRgBQgLAAgJAHIgEgKQALgGAOgBQAdABAAAfIAAAcQAAALACAIIgNAAIgBgKIAAAAQgJAMgOgBQgMABgGgIgAgQAQQAAAHAEAEQADADAHAAQAGAAAEgEQAFgEACgFIABgFIAAgMIgCAAQgeAAAAAQg");
	this.shape_102.setTransform(154.4,166.2);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#1A1F71").s().p("AASAnIAAhBIgjAAIAABBIgOAAIAAhNIA/AAIAABNg");
	this.shape_103.setTransform(146.5,166.1);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#1A1F71").s().p("AgfAsQAHgBAFgGQAIgFAEgKIABgEIgBgDIgchGIAPAAIARAuIAEAOIAFgPIAQgtIAOAAIgVA3QgHATgGALQgFALgHAGQgJAIgIABg");
	this.shape_104.setTransform(135,167.9);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#1A1F71").s().p("AAUAnIAAghIABgfIgBAAIgNAYIgXAoIgQAAIAAhNIANAAIAAAhIgBAeIABAAIANgYIAXgnIAQAAIAABNg");
	this.shape_105.setTransform(123.5,166.1);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#1A1F71").s().p("AgXAhQgJgJAAgSIAAgtIAOAAIAAAqQABAZARAAQAFAAAFgEQAFgEACgFQACgDgBgEIAAgvIAPAAIAAA4IAAAVIgNAAIAAgNIgBAAQgIAPgQAAQgLAAgHgHg");
	this.shape_106.setTransform(111.3,166.2);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#1A1F71").s().p("AgSAoIAAg1IgBgYIANAAIABAPIAAAAQACgIAGgEQAGgEAGgBIAFABIAAANIgGAAQgGAAgGAEQgEAFgBAJIgBAGIAAApg");
	this.shape_107.setTransform(104.8,166.1);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#1A1F71").s().p("AgGAHQgDgDABgEQgBgDADgDQADgDADAAQAEAAADADQACADABADQgBAEgCADQgDADgEAAQgEAAgCgDg");
	this.shape_108.setTransform(100.2,169.2);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#1A1F71").s().p("AAqAoIAAgsQAAgXgRAAQgGAAgEAEQgFADgCAGIgBAHIAAAvIgNAAIAAguQAAgJgEgGQgEgGgIAAQgGAAgFAEQgEAEgCAGIgBAHIAAAuIgOAAIAAg4IgBgVIANAAIAAANIABAAQAIgOAQgBQAIAAAGAFQAEAEADAHIAAAAQAEgHAFgDQAHgFAKgBQAKABAHAGQAJAJAAASIAAAtg");
	this.shape_109.setTransform(91.8,166.1);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#1A1F71").s().p("AgaAeQgLgMAAgRQAAgTAMgLQAKgLAQAAQAQABALAKQAKAMAAARQAAATgMALQgLALgPgBQgQABgKgLgAgRgUQgFAJgBALQABANAGAIQAGAJAKAAQAKAAAHgJQAGgIAAgNQABgLgGgIQgGgKgMAAQgKAAgHAJg");
	this.shape_110.setTransform(80.8,166.2);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#1A1F71").s().p("AgTAeQgLgMABgRQgBgSAMgLQALgMASAAQAMAAAHAFIgDALQgGgFgKAAQgLAAgIAJQgHAIAAAMQAAANAIAIQAHAIAKAAQAKAAAIgEIACALQgIAEgOAAQgQABgLgLg");
	this.shape_111.setTransform(72.9,166.2);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#1A1F71").s().p("AgGAHQgCgDAAgEQAAgDACgDQADgDADAAQAEAAADADQACADABADQgBAEgCADQgDADgEAAQgDAAgDgDg");
	this.shape_112.setTransform(67.7,169.2);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#1A1F71").s().p("AgYAhQgGgGAAgJQAAgOAMgHQAMgHAVAAIAAgCQAAgRgQgBQgLAAgJAHIgDgKQALgGANgBQAdABAAAfIAAAcQABALABAIIgNAAIgBgKIAAAAQgIAMgPgBQgLABgHgIgAgQAQQAAAHAEAEQAEADAFAAQAGAAAGgEQAFgEABgFIABgFIAAgMIgCAAQgeAAAAAQg");
	this.shape_113.setTransform(61.9,166.2);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#1A1F71").s().p("AgYAjIADgLQAJAFAKABQAGAAAEgDQAEgDAAgGQAAgFgEgDQgDgDgHgDQgUgHAAgOQAAgKAHgGQAHgGALgBQALABAIAEIgDALQgHgFgJAAQgFAAgDADQgEADAAAEQAAAFAEADQADADAHADQAUAGAAAQQAAALgHAFQgIAIgNgBQgMAAgJgFg");
	this.shape_114.setTransform(55.1,166.2);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#1A1F71").s().p("AgGA2IAAhMIANAAIAABMgAgFgmQgDgDAAgDQAAgEADgCQACgDADAAQAEAAACADQADACAAAEQAAADgDADQgCACgEAAQgDAAgCgCg");
	this.shape_115.setTransform(50.1,164.6);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#1A1F71").s().p("AgGAnIgehNIAPAAIAQArIAFAUIAAAAIAHgUIAPgrIAPAAIgfBNg");
	this.shape_116.setTransform(44.4,166.1);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#1A1F71").s().p("AgGAHQgDgDAAgEQAAgDADgDQADgDADAAQAEAAADADQACADAAADQAAAEgCADQgDADgEAAQgEAAgCgDg");
	this.shape_117.setTransform(39.1,169.2);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#1A1F71").s().p("AASAnIgLglQgFgOgCgLIAAAAQgCALgFAOIgMAlIgNAAIgXhNIAOAAIAKAnIAGAYIABAAIAGgYIANgnIALAAIAMAmIAHAZIAAAAQACgJAEgQIALgmIAOAAIgZBNg");
	this.shape_118.setTransform(31.4,166.1);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#1A1F71").s().p("AASAnIgLglQgFgOgCgLIAAAAQgCALgFAOIgMAlIgNAAIgXhNIAOAAIAKAnIAGAYIABAAIAGgYIANgnIALAAIAMAmIAHAZIAAAAQACgJAEgQIALgmIAOAAIgZBNg");
	this.shape_119.setTransform(19.7,166.1);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#1A1F71").s().p("AASAnIgLglQgFgOgCgLIAAAAQgCALgFAOIgMAlIgNAAIgXhNIAOAAIAKAnIAGAYIABAAIAGgYIANgnIALAAIAMAmIAHAZIAAAAQACgJAEgQIALgmIAOAAIgZBNg");
	this.shape_120.setTransform(7.9,166.1);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#1A1F71").s().p("AgXAdQgKgKAAgSQAAgRAKgLQAKgMAPAAQARAAAJAMQAGAKAAAOIAAAFIg2AAQABAOAHAHQAHAGALAAQAMAAAJgEIADAKQgLAFgPABQgRAAgKgMgAAVgHQAAgIgEgGQgFgJgLABQgJAAgGAHQgFAHgBAIIApAAIAAAAg");
	this.shape_121.setTransform(208.3,144.2);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#1A1F71").s().p("AgGAnIAAhBIgYAAIAAgMIA9AAIAAAMIgYAAIAABBg");
	this.shape_122.setTransform(201.1,144.1);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#1A1F71").s().p("AAUA2IAAggIAAgfIAAAAIgNAXIgXAoIgQAAIAAhMIANAAIAAAfIAAAgIAAAAIAMgYIAYgnIAQAAIAABMgAgUg2IALAAQAAANAJAAQAJAAABgNIAKAAQAAAVgUAAQgTAAgBgVg");
	this.shape_123.setTransform(193.4,142.6);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#1A1F71").s().p("AgYAiQgGgHAAgJQAAgOAMgGQAMgIAVAAIAAgBQAAgTgQABQgLAAgJAFIgDgJQAKgHAOABQAegBAAAgIAAAcQAAAMABAGIgNAAIgBgKIgBAAQgHANgPAAQgLgBgHgGgAgQARQAAAGAEADQAEAEAGAAQAGAAAEgEQAFgEACgFIABgEIAAgNIgCAAQgeAAAAARg");
	this.shape_124.setTransform(184.9,144.2);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#1A1F71").s().p("AgTAdQgLgKABgTQgBgQAMgMQALgLASAAQAMAAAHADIgDALQgGgDgKAAQgLAAgIAIQgHAJAAALQAAANAHAIQAIAIAKAAQAKAAAIgEIACAKQgIAFgOABQgQAAgLgMg");
	this.shape_125.setTransform(177.7,144.2);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#1A1F71").s().p("AgYAiQgGgHAAgJQAAgOAMgGQAMgIAWAAIAAgBQAAgTgRABQgLAAgJAFIgEgJQAMgHANABQAdgBAAAgIAAAcQAAAMACAGIgNAAIgBgKIAAAAQgJANgOAAQgMgBgGgGgAgQARQAAAGAEADQADAEAHAAQAFAAAFgEQAFgEACgFIABgEIAAgNIgCAAQgeAAAAARg");
	this.shape_126.setTransform(166.7,144.2);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#1A1F71").s().p("AASAnIAAgjIgjAAIAAAjIgOAAIAAhNIAOAAIAAAgIAjAAIAAggIAOAAIAABNg");
	this.shape_127.setTransform(158.7,144.1);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#1A1F71").s().p("AhKAFIAAgJICVAAIAAAJg");
	this.shape_128.setTransform(143,143.9);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#1A1F71").s().p("AATAnIAAghIABgfIAAAAIgNAYIgXAoIgQAAIAAhNIANAAIAAAhIAAAeIAAAAIAMgYIAYgnIAQAAIAABNg");
	this.shape_129.setTransform(127.2,144.1);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#1A1F71").s().p("AAUAnIAAghIABgfIgBAAIgNAYIgXAoIgQAAIAAhNIANAAIAAAhIgBAeIABAAIANgYIAWgnIARAAIAABNg");
	this.shape_130.setTransform(118.4,144.1);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#1A1F71").s().p("AAYAzIgBgZIg6AAIAAhMIAOAAIAABBIAjAAIAAhBIAOAAIAABCIAIAAIgBAjg");
	this.shape_131.setTransform(109.8,145.4);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#1A1F71").s().p("AARAnQgDgFgEgLQgEgKgGgEQgFgEgJAAIgDAAIAAAiIgOAAIAAhNIAOAAIAAAiIADAAIAcgiIARAAIggAjQAPACAKAVIAIATg");
	this.shape_132.setTransform(101.8,144.1);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#1A1F71").s().p("AgYAiQgGgHAAgJQAAgOAMgGQAMgIAVAAIAAgBQAAgTgQABQgLAAgJAFIgEgJQAMgHANABQAegBAAAgIAAAcQAAAMABAGIgNAAIgBgKIgBAAQgHANgPAAQgMgBgGgGgAgQARQAAAGAEADQAEAEAGAAQAFAAAFgEQAGgEABgFIABgEIAAgNIgCAAQgeAAAAARg");
	this.shape_133.setTransform(93.4,144.2);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#1A1F71").s().p("AATAnIAAggIgKAAQgJAAgDAEQgEADgDAHIgEAMIgDAGIgPAAIAEgJIAGgMQACgHAFgEQAEgEAFAAIAAgBQgJgBgGgDQgGgGAAgIQAAgLALgGQAIgFAQAAIAZABIAABMgAgNgPQABAHAHADQAFADAHAAIAMAAIAAgaIgMgBQgTAAgBAOg");
	this.shape_134.setTransform(82,144.1);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#1A1F71").s().p("AATAnIAAghIABgfIAAAAIgNAYIgXAoIgQAAIAAhNIANAAIAAAhIAAAeIAAAAIAMgYIAYgnIAQAAIAABNg");
	this.shape_135.setTransform(74.1,144.1);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#1A1F71").s().p("AASAnIAAgjIgjAAIAAAjIgOAAIAAhNIAOAAIAAAgIAjAAIAAggIAOAAIAABNg");
	this.shape_136.setTransform(65.3,144.1);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#1A1F71").s().p("AgXAdQgKgKAAgSQAAgRAKgLQAKgMAPAAQARAAAJAMQAGAKAAAOIAAAFIg2AAQABAOAHAHQAHAGALAAQAMAAAJgEIADAKQgLAFgPABQgRAAgKgMgAAVgHQAAgIgEgGQgFgJgLABQgJAAgGAHQgFAHgBAIIApAAIAAAAg");
	this.shape_137.setTransform(57,144.2);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#1A1F71").s().p("AAbAzIAAgZIg1AAIAAAZIgLAAIgBgjIAGAAQAFgHADgJQAFgNAAgRIAAgUIAyAAIAABCIAIAAIgBAjgAgHgbQAAAQgEANQgCAGgEAIIAjAAIAAg3IgZAAg");
	this.shape_138.setTransform(48.6,145.4);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#1A1F71").s().p("AgXAdQgKgKAAgSQAAgRAKgLQAKgMAPAAQARAAAJAMQAGAKAAAOIAAAFIg2AAQABAOAHAHQAHAGALAAQAMAAAJgEIADAKQgLAFgPABQgRAAgKgMgAAVgHQAAgIgEgGQgFgJgLABQgJAAgGAHQgFAHgBAIIApAAIAAAAg");
	this.shape_139.setTransform(40.5,144.2);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#1A1F71").s().p("AgeAmIAAhLQAKgCAOABQAigBAAAUQAAAGgFAFQgEAEgIACIAAABQAJAAAGAFQAFAEAAAJQAAAXgoAAIgVgCgAgRAdIALABQAXAAAAgNQAAgOgYAAIgKAAgAgRgcIAAAWIALAAQAUAAAAgMQAAgLgUAAg");
	this.shape_140.setTransform(32.8,144.2);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#1A1F71").s().p("AgaAdQgLgKAAgTQAAgRAMgMQAKgKAQAAQAQAAALALQAKAKAAASQAAATgMAMQgLAJgPABQgQAAgKgMgAgRgTQgFAHgBAMQABAMAGAJQAHAJAJgBQAKABAHgJQAGgJAAgMQABgLgGgIQgGgKgMAAQgLAAgGAKg");
	this.shape_141.setTransform(24.2,144.2);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#1A1F71").s().p("AgkA3IAAhSIAAgaIAMAAIACAOQAJgPARAAQAPAAAIAKQAKALAAASQAAATgLALQgKALgOAAQgPAAgIgNIAAAAIAAAqgAgMgmQgHAEgBAIIgBAGIAAANIABAGQABAGAGAFQAGAEAHAAQALAAAGgIQAGgHAAgNQAAgNgGgIQgHgIgKAAQgHAAgFAFg");
	this.shape_142.setTransform(15.5,145.6);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#1A1F71").s().p("AASAnIAAhBIgjAAIAABBIgOAAIAAhNIA/AAIAABNg");
	this.shape_143.setTransform(6.4,144.1);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#1A1F71").s().p("AATAnIAAggIgKAAQgIAAgEAEQgEADgDAHIgEAMIgDAGIgPAAIAEgJIAGgMQADgHAEgEQAEgEAFAAIAAgBQgJgBgGgDQgGgGAAgIQAAgLAKgGQAKgFAPAAIAZABIAABMgAgMgPQAAAHAHADQAFADAHAAIAMAAIAAgaIgMgBQgTAAAAAOg");
	this.shape_144.setTransform(229.9,122.1);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#1A1F71").s().p("AAUAnIAAghIABgfIgBAAIgNAYIgXAoIgQAAIAAhNIANAAIAAAhIgBAeIABAAIANgYIAWgnIARAAIAABNg");
	this.shape_145.setTransform(222,122.1);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#1A1F71").s().p("AgeAmIAAhLQAKgCAOAAQAiAAAAATQAAAIgFAEQgEAFgIABIAAAAQAJACAGADQAFAFAAAJQAAAWgoAAIgVgBgAgRAdIALABQAXAAAAgNQAAgOgYAAIgKAAgAgRgdIAAAXIALAAQAUABAAgMQAAgMgUAAg");
	this.shape_146.setTransform(213.8,122.2);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#1A1F71").s().p("AgaAdQgLgLAAgRQAAgTAMgLQAKgLAPAAQARABAKAKQALAMAAARQAAATgMALQgLALgPgBQgQABgKgMgAgRgUQgGAIAAAMQAAAMAHAJQAHAIAJAAQAKAAAHgIQAGgIABgNQAAgLgGgIQgGgKgMAAQgKAAgHAJg");
	this.shape_147.setTransform(205.2,122.2);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#1A1F71").s().p("AgiAcQAFAAADgDQAFgEABgIQACgHAAgNIAAgfIA1AAIAABMIgOAAIAAhBIgaAAIAAAUQAAARgCAJQgDALgHAEQgGAFgJAAg");
	this.shape_148.setTransform(196.2,122.2);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#1A1F71").s().p("AgTAdQgKgLAAgRQAAgSALgLQALgMASAAQAMAAAIAFIgEALQgGgEgKgBQgMAAgHAJQgHAJAAALQAAANAHAIQAIAIAKAAQAJAAAJgEIADALQgJAEgOAAQgRABgKgMg");
	this.shape_149.setTransform(189.2,122.2);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#1A1F71").s().p("AggA2IABgMIAFABQANAAAIgTQACgDgCgDIgkhIIAQAAIAVAuIAHATIABAAIAGgTIARguIAPAAIgXA3QgMAegHAKQgLAOgNAAIgIgBg");
	this.shape_150.setTransform(181.4,120.7);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#1A1F71").s().p("AgGAHQgDgDAAgEQAAgDADgDQADgDADAAQAEAAADADQADADAAADQAAAEgDADQgDADgEAAQgEAAgCgDg");
	this.shape_151.setTransform(172.4,125.2);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#1A1F71").s().p("AgPBBQAUgcgBglQABglgUgbIALAAQAUAbAAAlQAAAlgUAcg");
	this.shape_152.setTransform(168,121.4);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#1A1F71").s().p("AgfAsQAHgBAFgGQAIgFAEgKIABgEIgBgDIgchGIAPAAIARAtIAEAPIAFgPIAQgtIAOAAIgVA2QgHAVgGAKQgFALgHAGQgJAIgIABg");
	this.shape_153.setTransform(162.3,123.9);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#1A1F71").s().p("AgYAhQgGgGAAgJQAAgOAMgHQAMgHAWAAIAAgCQAAgSgRAAQgLABgJAFIgEgJQAMgGANgBQAdABAAAfIAAAcQAAALACAHIgNAAIgBgJIgBAAQgIAMgOgBQgMABgGgIgAgQARQAAAGAEAEQADADAHAAQAFAAAFgEQAFgDACgGIABgFIAAgMIgCAAQgeAAAAARg");
	this.shape_154.setTransform(154.5,122.2);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#1A1F71").s().p("AggA2IAAhpQAMgCAPAAQATAAAKAJQAJAIAAAOQAAAPgIAHQgLAMgVAAIgLgBIAAArgAgSgpIAAApIALABQAMAAAHgFQAHgGAAgLQAAgLgHgFQgGgFgLAAIgNABg");
	this.shape_155.setTransform(146.9,120.6);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#1A1F71").s().p("AATAoIAAgsQAAgXgSAAQgFAAgGAEQgFAFgCAFIAAAHIAAAuIgPAAIAAg4IAAgVIAMAAIABANQAEgGAGgEQAHgEAIgBQAKABAIAGQAJAJAAASIAAAtg");
	this.shape_156.setTransform(134.6,122.1);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#1A1F71").s().p("AgGA2IAAhMIANAAIAABMgAgFgmQgDgDAAgDQAAgEADgCQACgDADAAQAEAAACADQADACAAAEQAAADgDADQgCACgEAAQgDAAgCgCg");
	this.shape_157.setTransform(128.3,120.6);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#1A1F71").s().p("AAqAoIAAgsQAAgXgRAAQgGAAgEAEQgFADgCAGIgBAHIAAAvIgNAAIAAguQAAgJgEgGQgEgGgIAAQgGAAgFAEQgEAEgCAGIgBAHIAAAuIgOAAIAAg4IgBgVIANAAIAAANIABAAQAIgOAQgBQAIAAAGAFQAEAEADAHIAAAAQAEgGAFgEQAHgFAKgBQAKABAHAGQAJAJAAASIAAAtg");
	this.shape_158.setTransform(119.8,122.1);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#1A1F71").s().p("AgSAoIAAg1IAAgYIAMAAIAAAPIABAAQADgHAEgFQAHgEAHgBIADABIAAANIgFAAQgGAAgGAEQgEAGgBAIIgBAGIAAApg");
	this.shape_159.setTransform(111,122.1);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#1A1F71").s().p("AgYAhQgGgGAAgJQAAgOAMgHQAMgHAWAAIAAgCQAAgSgRAAQgLABgJAFIgEgJQALgGAOgBQAeABgBAfIAAAcQABALABAHIgNAAIgBgJIAAAAQgJAMgOgBQgMABgGgIgAgQARQAAAGAEAEQADADAHAAQAGAAAFgEQAEgDACgGIABgFIAAgMIgCAAQgeAAAAARg");
	this.shape_160.setTransform(103.9,122.2);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#1A1F71").s().p("AgcApQgPgPAAgZQAAgYAPgPQARgQAZAAQARAAAKAFIgDALQgKgEgOAAQgTAAgLALQgMAMgBATQAAAVAMALQALALASAAQANAAAGgCIAAghIgWAAIAAgKIAjAAIAAAzQgRAGgQAAQgZAAgOgOg");
	this.shape_161.setTransform(95,120.6);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#1A1F71").s().p("AgCgRIAPgCQgHAYgIAOIgKABQAHgSADgTg");
	this.shape_162.setTransform(84.8,126);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#1A1F71").s().p("AgfAsQAHgBAFgGQAIgFAEgKIABgEIgBgDIgchGIAPAAIARAtIAEAPIAFgPIAQgtIAOAAIgVA2QgHAVgGAKQgFALgHAGQgJAIgIABg");
	this.shape_163.setTransform(79.6,123.9);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#1A1F71").s().p("AgYAhQgGgGAAgJQAAgOAMgHQAMgHAVAAIAAgCQAAgSgQAAQgLABgJAFIgDgJQALgGANgBQAdABAAAfIAAAcQABALABAHIgNAAIgBgJIAAAAQgIAMgPgBQgLABgHgIgAgQARQAAAGAEAEQAEADAFAAQAGAAAGgEQAFgDABgGIABgFIAAgMIgCAAQgeAAAAARg");
	this.shape_164.setTransform(71.8,122.2);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#1A1F71").s().p("AggA2IAAhpQAMgCAPAAQATAAAKAJQAJAIAAAOQAAAPgIAHQgLAMgVAAIgLgBIAAArgAgSgpIAAApIALABQAMAAAHgFQAHgGAAgLQAAgLgHgFQgGgFgLAAIgNABg");
	this.shape_165.setTransform(64.1,120.6);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#1A1F71").s().p("AgaAvQgJgLAAgSQAAgSAKgLQAJgLAQAAQAPAAAGALIABAAIAAguIAOAAIAABdIABAUIgNAAIgBgOIAAAAQgDAHgHAEQgHAFgJAAQgOAAgJgLgAgPgDQgGAHAAAOQAAAMAGAIQAGAIAKAAQAHAAAFgEQAHgFABgIIABgGIAAgNIgBgGQgBgGgGgFQgFgEgIAAQgJAAgHAIg");
	this.shape_166.setTransform(51.5,120.4);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#1A1F71").s().p("AgGA2IAAhMIANAAIAABMgAgFgmQgDgDAAgDQAAgEADgCQACgDADAAQAEAAACADQADACAAAEQAAADgDADQgCACgEAAQgDAAgCgCg");
	this.shape_167.setTransform(45.4,120.6);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#1A1F71").s().p("AgaAdQgLgLAAgRQAAgTALgLQALgLAPAAQARABAKAKQALAMAAARQAAATgMALQgLALgPgBQgQABgKgMgAgRgUQgGAIAAAMQAAAMAHAJQAGAIAKAAQAKAAAHgIQAGgIABgNQAAgLgGgIQgHgKgLAAQgLAAgGAJg");
	this.shape_168.setTransform(39.2,122.2);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#1A1F71").s().p("AgSAoIAAg1IgBgYIANAAIABAPIAAAAQACgHAGgFQAFgEAIgBIADABIAAANIgEAAQgIAAgFAEQgEAGgBAIIgBAGIAAApg");
	this.shape_169.setTransform(32.7,122.1);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#1A1F71").s().p("AgaAvQgKgLABgSQgBgSALgLQAJgLAPAAQAQAAAGALIABAAIAAguIAOAAIAABdIABAUIgNAAIgBgOIAAAAQgEAHgGAEQgHAFgJAAQgNAAgKgLgAgPgDQgGAHAAAOQAAAMAGAIQAGAIAKAAQAHAAAFgEQAHgFABgIIABgGIAAgNIgBgGQgBgGgGgFQgFgEgIAAQgKAAgGAIg");
	this.shape_170.setTransform(24.9,120.4);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#1A1F71").s().p("AATAoIAAgsQAAgXgSAAQgFAAgGAEQgFAFgCAFIAAAHIAAAuIgPAAIAAg4IAAgVIAMAAIABANQAEgGAGgEQAHgEAIgBQAKABAIAGQAJAJAAASIAAAtg");
	this.shape_171.setTransform(16.2,122.1);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#1A1F71").s().p("AAfA2IgMgiIgmAAIgKAiIgPAAIAkhrIAQAAIAlBrgAAQAJIgKgeIgGgTIAAAAIgFATIgLAeIAgAAg");
	this.shape_172.setTransform(6.9,120.6);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#1A1F71").s().p("AgCgRIAPgCQgHAYgIAOIgKABQAHgSADgTg");
	this.shape_173.setTransform(252.3,104);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#1A1F71").s().p("AgfAtQAHgCAFgFQAIgHAEgJIABgDIgBgEIgchHIAPAAIARAvIAEAOIAFgPIAQguIAOAAIgVA4QgHATgGALQgFALgHAHQgJAHgIABg");
	this.shape_174.setTransform(247.1,101.9);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#1A1F71").s().p("AgYAhQgGgGAAgJQAAgOAMgGQAMgIAWAAIAAgBQgBgSgQAAQgLgBgJAHIgEgKQAMgGANAAQAegBgBAgIAAAcQABALABAIIgNAAIgBgLIAAAAQgJAMgOABQgMAAgGgIgAgQAQQAAAHAEADQADAEAGAAQAGAAAGgEQAEgEACgFIABgEIAAgNIgCAAQgeAAAAAQg");
	this.shape_175.setTransform(239.3,100.2);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#1A1F71").s().p("AggA2IAAhpQAMgCAPAAQATAAAKAJQAJAIAAAOQAAAPgIAHQgLAMgVAAIgLgBIAAArgAgSgpIAAApIALABQAMAAAHgFQAHgGAAgLQAAgLgHgFQgGgFgLAAIgNABg");
	this.shape_176.setTransform(231.6,98.6);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#1A1F71").s().p("AgXAeQgKgLAAgSQAAgRAKgMQAKgMAPABQARAAAJAMQAGAKAAAOIAAAGIg2AAQABANAHAHQAHAGALAAQAMAAAJgEIADAKQgLAGgPAAQgRgBgKgKgAAVgHQAAgIgEgGQgFgJgLABQgJAAgGAHQgFAHgBAIIApAAIAAAAg");
	this.shape_177.setTransform(219.8,100.2);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#1A1F71").s().p("AgGA5IAAhxIANAAIAABxg");
	this.shape_178.setTransform(213.9,98.3);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#1A1F71").s().p("AgcAyIADgLQAKAGANAAQAYAAAAgbIAAgJIgBAAQgHANgQAAQgPAAgJgKQgJgLAAgPQAAgTALgMQAKgKAOAAQAQAAAHANIAAAAIABgMIAMAAIgBAWIAAAsQAAAZgLAKQgJAJgSAAQgQAAgJgGgAgOgkQgHAIAAANQAAAMAGAGQAGAJAKAAQAHAAAFgEQAFgEACgGQACgDAAgEIAAgOIgBgHQgCgGgFgEQgGgEgHAAQgJAAgGAIg");
	this.shape_179.setTransform(207.3,101.7);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#1A1F71").s().p("AgaAeQgLgLAAgTQAAgRAMgMQAKgKAQAAQAQgBALALQAKALAAASQAAATgMAMQgLAJgPABQgQgBgKgKgAgRgUQgFAJgBALQABAMAGAJQAHAJAJAAQAKAAAHgJQAGgJAAgMQABgLgGgIQgGgKgMAAQgLAAgGAJg");
	this.shape_180.setTransform(198.8,100.2);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#1A1F71").s().p("AgaAeQgLgLAAgTQAAgRAMgMQAKgKAQAAQAQgBALALQAKALAAASQAAATgNAMQgKAJgPABQgQgBgKgKgAgRgUQgFAJgBALQABAMAGAJQAHAJAJAAQAKAAAGgJQAIgJgBgMQABgLgGgIQgGgKgMAAQgKAAgHAJg");
	this.shape_181.setTransform(190,100.2);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#1A1F71").s().p("AgcApQgPgOAAgbQAAgXAQgPQAQgQAZAAQARAAAKAFIgDAMQgLgGgNAAQgTABgLAMQgMALAAATQgBAUAMAMQALAMASAAQANAAAFgDIAAghIgVAAIAAgJIAjAAIAAAyQgQAGgRAAQgYAAgPgOg");
	this.shape_182.setTransform(180.3,98.6);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#1A1F71").s().p("AgCgRIAPgCQgHAYgIAOIgKABQAHgSADgTg");
	this.shape_183.setTransform(170.2,104);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#1A1F71").s().p("AgfAtQAHgCAFgFQAIgHAEgJIABgDIgBgEIgchHIAPAAIARAvIAEAOIAFgPIAQguIAOAAIgVA4QgHATgGALQgFALgHAHQgJAHgIABg");
	this.shape_184.setTransform(164.9,101.9);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#1A1F71").s().p("AgYAhQgGgGAAgJQAAgOAMgGQAMgIAWAAIAAgBQAAgSgRAAQgLgBgJAHIgEgKQALgGAOAAQAdgBAAAgIAAAcQAAALACAIIgNAAIgBgLIAAAAQgJAMgOABQgMAAgGgIgAgQAQQAAAHAEADQADAEAHAAQAGAAAEgEQAFgEACgFIABgEIAAgNIgCAAQgeAAAAAQg");
	this.shape_185.setTransform(157.1,100.2);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#1A1F71").s().p("AggA2IAAhpQAMgCAPAAQATAAAKAJQAJAIAAAOQAAAPgIAHQgLAMgVAAIgLgBIAAArgAgSgpIAAApIALABQAMAAAHgFQAHgGAAgLQAAgLgHgFQgGgFgLAAIgNABg");
	this.shape_186.setTransform(149.5,98.6);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#1A1F71").s().p("AgcAyIADgLQAKAGANAAQAYAAAAgbIAAgJIgBAAQgHANgQAAQgPAAgJgKQgJgLAAgPQAAgTALgMQAKgKAOAAQAQAAAHANIAAAAIABgMIAMAAIgBAWIAAAsQAAAZgLAKQgJAJgSAAQgQAAgJgGgAgOgkQgHAIAAANQAAAMAGAGQAGAJAKAAQAHAAAFgEQAFgEACgGQACgDAAgEIAAgOIgBgHQgCgGgFgEQgGgEgHAAQgJAAgGAIg");
	this.shape_187.setTransform(136.9,101.7);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#1A1F71").s().p("AATAoIAAgsQAAgXgSAAQgFAAgGAEQgFAEgCAHIAAAGIAAAuIgPAAIAAg4IAAgVIAMAAIABANQAEgGAGgEQAHgFAIABQAKAAAIAGQAJAJAAARIAAAug");
	this.shape_188.setTransform(128.3,100.1);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#1A1F71").s().p("AgXAhQgJgJAAgSIAAgtIAPAAIAAAqQgBAZASAAQAFAAAGgEQAEgEACgFQABgDABgEIAAgvIANAAIAAA4IABAVIgNAAIAAgNIAAAAQgJAPgQAAQgLAAgHgHg");
	this.shape_189.setTransform(119.5,100.2);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#1A1F71").s().p("AgYAjIADgLQAJAGAKAAQAGgBAEgDQAEgDAAgFQAAgFgEgDQgDgDgHgDQgUgGAAgPQAAgKAHgGQAHgGALAAQALgBAIAFIgDAKQgHgEgJAAQgFAAgDADQgEADAAAEQAAAFAEADQADADAHADQAUAHAAAPQAAAKgHAGQgIAIgNAAQgMgBgJgFg");
	this.shape_190.setTransform(111.9,100.2);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#1A1F71").s().p("AAqAoIAAgrQAAgYgRAAQgGAAgEADQgFAEgCAFIgBAHIAAAwIgNAAIAAguQAAgJgEgGQgEgGgIAAQgGAAgFAEQgEAEgCAGIgBAHIAAAuIgOAAIAAg4IgBgVIANAAIAAAMIABAAQAIgOAQABQAIAAAGADQAEAFADAHIAAAAQAEgGAFgEQAHgGAKABQAKAAAHAGQAJAJAAASIAAAtg");
	this.shape_191.setTransform(102.1,100.1);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#1A1F71").s().p("AgYAhQgGgGAAgJQAAgOAMgGQAMgIAWAAIAAgBQAAgSgRAAQgLgBgJAHIgEgKQALgGAOAAQAdgBAAAgIAAAcQAAALACAIIgNAAIgBgLIAAAAQgJAMgOABQgMAAgGgIgAgQAQQAAAHAEADQADAEAHAAQAGAAAEgEQAFgEACgFIABgEIAAgNIgCAAQgeAAAAAQg");
	this.shape_192.setTransform(91.4,100.2);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#1A1F71").s().p("AggAwIAEgLQALAHAOAAQAJAAAHgFQAFgFAAgJQAAgHgEgFQgFgFgKgEQgcgJAAgVQAAgMAJgIQAKgJAPAAQAOAAAJAFIgDAMQgKgFgLAAQgJAAgGAFQgEAEAAAHQAAAHAFAFQAFAEAKAFQAOAFAHAGQAHAIAAALQAAAOgKAIQgKAKgRAAQgRAAgLgIg");
	this.shape_193.setTransform(83.8,98.6);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#1A1F71").s().p("AgCgRIAPgCQgHAYgIAOIgKABQAHgSADgTg");
	this.shape_194.setTransform(74.8,104);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#1A1F71").s().p("AgfAtQAHgCAFgFQAIgHAEgJIABgDIgBgEIgchHIAPAAIARAvIAEAOIAFgPIAQguIAOAAIgVA4QgHATgGALQgFALgHAHQgJAHgIABg");
	this.shape_195.setTransform(69.5,101.9);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#1A1F71").s().p("AgYAhQgGgGAAgJQAAgOAMgGQAMgIAWAAIAAgBQAAgSgRAAQgLgBgJAHIgEgKQALgGAOAAQAdgBAAAgIAAAcQAAALACAIIgNAAIgBgLIAAAAQgJAMgOABQgMAAgGgIgAgQAQQAAAHAEADQADAEAHAAQAGAAAEgEQAFgEACgFIABgEIAAgNIgCAAQgeAAAAAQg");
	this.shape_196.setTransform(61.7,100.2);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#1A1F71").s().p("AggA2IAAhpQAMgCAPAAQATAAAKAJQAJAIAAAOQAAAPgIAHQgLAMgVAAIgLgBIAAArgAgSgpIAAApIALABQAMAAAHgFQAHgGAAgLQAAgLgHgFQgGgFgLAAIgNABg");
	this.shape_197.setTransform(54.1,98.6);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#1A1F71").s().p("AgXAeQgKgLAAgSQAAgRAKgMQAKgMAPABQARAAAJAMQAGAKAAAOIAAAGIg2AAQABANAHAHQAHAGALAAQAMAAAJgEIADAKQgLAGgPAAQgRgBgKgKgAAVgHQAAgIgEgGQgFgJgLABQgJAAgGAHQgFAHgBAIIApAAIAAAAg");
	this.shape_198.setTransform(42.2,100.2);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#1A1F71").s().p("AgGA5IAAhxIANAAIAABxg");
	this.shape_199.setTransform(36.3,98.3);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#1A1F71").s().p("AgkA3IAAhSIAAgaIANAAIABAOQAJgPARAAQAPAAAJAKQAJALAAASQAAATgLALQgKALgOAAQgQAAgHgNIgBAAIAAAqgAgNgmQgFAEgDAIIgBAGIAAANIABAGQACAGAGAFQAGAEAHAAQALAAAFgIQAHgHAAgNQAAgNgGgIQgHgIgKAAQgHAAgGAFg");
	this.shape_200.setTransform(30.2,101.6);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#1A1F71").s().p("AgkA3IAAhSIAAgaIANAAIABAOQAJgPARAAQAPAAAIAKQAKALAAASQAAATgLALQgKALgOAAQgPAAgIgNIAAAAIAAAqgAgMgmQgHAEgCAIIAAAGIAAANIAAAGQACAGAGAFQAGAEAHAAQALAAAFgIQAHgHAAgNQAAgNgGgIQgHgIgKAAQgHAAgFAFg");
	this.shape_201.setTransform(21.1,101.6);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#1A1F71").s().p("AAfA2IgMgiIgmAAIgKAiIgPAAIAkhrIAQAAIAlBrgAAQAJIgKgeIgGgUIAAAAIgFAUIgLAeIAgAAg");
	this.shape_202.setTransform(11.4,98.6);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#1A1F71").s().p("AAFBBQgUgcAAglQAAglAUgbIALAAQgTAbAAAlQAAAlATAcg");
	this.shape_203.setTransform(4.6,99.4);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#1A1F71").s().p("AgYAiQgGgHAAgJQAAgOAMgHQAMgHAWAAIAAgCQAAgSgRAAQgLABgJAFIgEgJQAMgHANAAQAdAAAAAgIAAAcQAAALACAHIgNAAIgBgKIAAAAQgJAMgOAAQgMAAgGgGgAgQARQAAAGAEAEQADADAHAAQAFAAAFgEQAFgDACgGIABgFIAAgMIgCAAQgeAAAAARg");
	this.shape_204.setTransform(225.2,78.2);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#1A1F71").s().p("AgYAjIADgLQAJAFAKAAQAGAAAEgCQAEgDAAgGQAAgFgEgDQgDgDgHgDQgUgHAAgOQAAgJAHgHQAHgHALAAQALAAAIAFIgDAKQgHgEgJAAQgFAAgDADQgEADAAAFQAAAEAEADQADACAHADQAUAIAAAPQAAAKgHAHQgIAGgNAAQgMABgJgGg");
	this.shape_205.setTransform(218.4,78.2);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#1A1F71").s().p("AgGA2IAAhMIANAAIAABMgAgFgmQgDgCAAgEQAAgEADgCQACgDADAAQAEAAACADQADACAAAEQAAAEgDACQgCADgEAAQgDAAgCgDg");
	this.shape_206.setTransform(213.4,76.6);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#1A1F71").s().p("AgIA2IgkhrIAPAAIARA1IAMAnIAAAAQACgOAJgZIATg1IAPAAIgnBrg");
	this.shape_207.setTransform(207.1,76.6);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#1A1F71").s().p("AAUA2IAAghIABgeIgBAAIgNAXIgXAoIgQAAIAAhMIANAAIAAAfIgBAgIABAAIANgYIAWgnIARAAIAABMgAgUg2IAKAAQABAMAJAAQAJAAABgMIALAAQgCAUgTAAQgTAAgBgUg");
	this.shape_208.setTransform(194.9,76.6);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#1A1F71").s().p("AgaAdQgLgLAAgRQAAgTAMgLQAKgLAQAAQAQAAALAMQAKAKAAASQAAATgMALQgLAKgPAAQgQAAgKgLgAgRgTQgFAHgBAMQABAMAGAJQAGAIAKAAQAKAAAHgIQAGgIAAgNQABgLgGgIQgGgKgMAAQgKAAgHAKg");
	this.shape_209.setTransform(186.1,78.2);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#1A1F71").s().p("AgGAnIAAhBIgYAAIAAgMIA9AAIAAAMIgYAAIAABBg");
	this.shape_210.setTransform(178.4,78.1);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#1A1F71").s().p("AgkA3IAAhSIAAgaIANAAIABAOQAJgPARAAQAPAAAIAKQAKALAAASQAAATgLALQgKALgOAAQgPAAgIgNIAAAAIAAAqgAgMgmQgHAEgBAIIgBAGIAAANIABAGQABAGAGAFQAGAEAHAAQALAAAFgIQAHgHAAgNQAAgNgGgIQgGgIgLAAQgHAAgFAFg");
	this.shape_211.setTransform(170.8,79.6);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#1A1F71").s().p("AgYAiQgGgHAAgJQAAgOAMgHQAMgHAWAAIAAgCQAAgSgRAAQgLABgJAFIgEgJQALgHAOAAQAeAAgBAgIAAAcQABALABAHIgNAAIgBgKIAAAAQgJAMgOAAQgMAAgGgGgAgQARQAAAGAEAEQADADAHAAQAGAAAFgEQAEgDACgGIABgFIAAgMIgCAAQgeAAAAARg");
	this.shape_212.setTransform(162,78.2);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#1A1F71").s().p("AARAnQgDgFgEgLQgEgKgGgEQgFgEgJAAIgDAAIAAAiIgOAAIAAhNIAOAAIAAAiIADAAIAcgiIARAAIggAjQAPACAKAVIAIATg");
	this.shape_213.setTransform(155,78.1);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#1A1F71").s().p("AgYAiQgGgHAAgJQAAgOAMgHQAMgHAWAAIAAgCQAAgSgRAAQgLABgJAFIgEgJQAMgHANAAQAdAAAAAgIAAAcQAAALACAHIgNAAIgBgKIgBAAQgIAMgOAAQgMAAgGgGgAgQARQAAAGAEAEQADADAHAAQAFAAAFgEQAFgDACgGIABgFIAAgMIgCAAQgeAAAAARg");
	this.shape_214.setTransform(143.3,78.2);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#1A1F71").s().p("AAmAnIgHgSQgGgQgQAAIgDAAIAAAiIgMAAIAAgiIgCAAQgIAAgGADQgFAEgEAJIgHASIgNAAIAIgWQAHgSAQgCIgfgjIARAAIAaAiIACAAIAAgiIAMAAIAAAiIAEAAIAZgiIAQAAIgfAjQARACAHASIAJAWg");
	this.shape_215.setTransform(134.3,78.1);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#1A1F71").s().p("AgXAdQgKgKAAgSQAAgRAKgLQAKgNAPAAQARAAAJANQAGAKAAAOIAAAFIg2AAQABAOAHAHQAHAGALAAQAMAAAJgEIADALQgLAEgPAAQgRAAgKgLgAAVgGQAAgKgEgGQgFgHgLgBQgJAAgGAIQgFAGgBAKIApAAIAAAAg");
	this.shape_216.setTransform(125,78.2);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#1A1F71").s().p("AgGAnIAAhBIgYAAIAAgMIA9AAIAAAMIgYAAIAABBg");
	this.shape_217.setTransform(117.7,78.1);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#1A1F71").s().p("AgYAiQgGgHAAgJQAAgOAMgHQAMgHAVAAIAAgCQAAgSgQAAQgLABgJAFIgDgJQALgHANAAQAdAAABAgIAAAcQgBALACAHIgNAAIgBgKIgBAAQgIAMgOAAQgMAAgGgGgAgQARQAAAGAEAEQAEADAFAAQAGAAAGgEQAFgDABgGIABgFIAAgMIgCAAQgeAAAAARg");
	this.shape_218.setTransform(110.4,78.2);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#1A1F71").s().p("AgiAcQAFAAADgDQAFgEABgIQACgHAAgNIAAgfIA1AAIAABMIgOAAIAAhBIgaAAIAAAUQAAARgCAJQgDALgHAEQgGAFgJAAg");
	this.shape_219.setTransform(102.1,78.2);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#1A1F71").s().p("AASAnIAAhBIgjAAIAABBIgOAAIAAhNIA/AAIAABNg");
	this.shape_220.setTransform(94.3,78.1);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#1A1F71").s().p("AgaAdQgLgLAAgRQAAgTALgLQALgLAPAAQARAAAKAMQALAKAAASQAAATgNALQgKAKgPAAQgQAAgKgLgAgRgTQgGAHABAMQAAAMAGAJQAGAIAKAAQAKAAAGgIQAIgIgBgNQAAgLgFgIQgHgKgLAAQgLAAgGAKg");
	this.shape_221.setTransform(82.3,78.2);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#1A1F71").s().p("AgXAnIAAhNIAvAAIAAAMIghAAIAABBg");
	this.shape_222.setTransform(75.2,78.1);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#1A1F71").s().p("AgaAdQgLgLAAgRQAAgTAMgLQAKgLAQAAQAQAAALAMQAKAKAAASQAAATgMALQgLAKgPAAQgQAAgKgLgAgRgTQgFAHgBAMQABAMAGAJQAHAIAJAAQAKAAAHgIQAGgIAAgNQABgLgGgIQgGgKgMAAQgLAAgGAKg");
	this.shape_223.setTransform(67.4,78.2);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#1A1F71").s().p("AASAnIAAgjIgjAAIAAAjIgOAAIAAhNIAOAAIAAAgIAjAAIAAggIAOAAIAABNg");
	this.shape_224.setTransform(58.6,78.1);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#1A1F71").s().p("AgeAmIAAhMIAOAAIAAAaIAMgBQAjAAAAAZQAAALgIAHQgLAJgWAAQgKAAgKgBgAgQgCIAAAeIAKABQAJAAAGgDQAIgFAAgIQAAgQgXAAg");
	this.shape_225.setTransform(50.6,78.2);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#1A1F71").s().p("AgiAcQAFAAADgDQAFgEABgIQACgHAAgNIAAgfIA1AAIAABMIgOAAIAAhBIgaAAIAAAUQAAARgCAJQgDALgHAEQgGAFgJAAg");
	this.shape_226.setTransform(41.7,78.2);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#1A1F71").s().p("AATAnIAAghIABgfIAAAAIgNAYIgXAoIgQAAIAAhNIANAAIAAAhIAAAeIAAAAIAMgYIAYgnIAQAAIAABNg");
	this.shape_227.setTransform(33.8,78.1);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#1A1F71").s().p("AgbAqQgIgNAAgWQAAgbAMgPQAKgPAWgDIAUgFIgBAMIgQAEQgTADgIALQgHALgBAPIAAAAQAEgIAHgFQAIgFAHAAQAPAAAIAKQAKAKAAASQAAATgKALQgJALgRAAQgSAAgJgRgAgQAAQgEAHAAAKQAAALAFAJQAGALAKAAQAKAAAGgJQAEgIABgMQgBgMgEgHQgGgJgLAAQgLAAgFAJg");
	this.shape_228.setTransform(25.2,76.3);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#1A1F71").s().p("AgaAdQgLgLAAgRQAAgTALgLQALgLAPAAQARAAALAMQAKAKAAASQAAATgMALQgLAKgPAAQgQAAgKgLgAgRgTQgGAHAAAMQAAAMAHAJQAHAIAJAAQAKAAAHgIQAGgIABgNQAAgLgGgIQgGgKgMAAQgKAAgHAKg");
	this.shape_229.setTransform(16.6,78.2);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#1A1F71").s().p("AAgAnIgCglIgCgbIgBAAIgIAZIgPAmIgJAAIgOgmIgIgZIAAAAIgCAbIgBAlIgOAAIAGhNIASAAIAOAmIAGAWIAJgaIANgiIARAAIAFBNg");
	this.shape_230.setTransform(7.1,78.1);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#1A1F71").s().p("AgKAfQgIgKgCgQIgNAAIAAAiIgOAAIAAhNIAOAAIAAAhIANAAQACgPAJgKQAJgJAOAAQAPgBAKALQAIALABASQAAARgLAMQgJAMgPAAQgNAAgKgKgAgBgUQgGAIAAAMQABAMAEAJQAGAJAJAAQAKAAAFgKQAGgJgBgLQABgMgGgIQgFgJgJAAQgLAAgEAJg");
	this.shape_231.setTransform(226.2,56.2);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#1A1F71").s().p("AgeAmIAAhMIAOAAIAAAaIAMgBQAjAAAAAZQAAALgIAHQgLAJgWAAQgKAAgKgBgAgQgCIAAAeIAKABQAJAAAGgDQAIgFAAgIQAAgQgXAAg");
	this.shape_232.setTransform(216.6,56.2);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#1A1F71").s().p("AAoAzIgBgYIhZAAIAAhNIANAAIAABBIAbAAIAAhBIANAAIAABBIAbAAIAAhBIAOAAIAABCIAHAAIAAAjg");
	this.shape_233.setTransform(206.7,57.4);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#1A1F71").s().p("AgaAeQgLgLAAgTQAAgSALgLQALgKAPAAQARgBAKALQALALAAASQAAATgNAMQgKAKgPAAQgQgBgKgKgAgRgUQgGAJABALQgBANAHAIQAGAJAKAAQAKAAAGgJQAIgIAAgNQgBgLgFgIQgHgKgLAAQgLAAgGAJg");
	this.shape_234.setTransform(196,56.2);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#1A1F71").s().p("AAfAnIgCglIgBgbIAAAAIgJAZIgPAmIgJAAIgOgmIgHgZIgBAAIgCAbIgCAlIgMAAIAFhNIASAAIAOAmIAGAWIAKgaIAMgiIARAAIAGBNg");
	this.shape_235.setTransform(186.5,56.1);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#1A1F71").s().p("AgaAeQgLgLAAgTQAAgSAMgLQAKgKAQAAQAQgBALALQAKALAAASQAAATgMAMQgLAKgPAAQgQgBgKgKgAgRgUQgFAJgBALQABANAGAIQAGAJAKAAQAKAAAHgJQAGgIAAgNQABgLgGgIQgGgKgMAAQgKAAgHAJg");
	this.shape_236.setTransform(177.1,56.2);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#1A1F71").s().p("AASAnIAAhBIgjAAIAABBIgOAAIAAhNIA/AAIAABNg");
	this.shape_237.setTransform(168.4,56.1);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#1A1F71").s().p("AgTAeQgLgLAAgTQAAgQAMgMQAMgLARAAQALAAAIADIgCAMQgHgFgKAAQgLAAgIAJQgHAIAAAMQAAANAIAIQAHAIALAAQAIAAAJgEIACAKQgJAGgNAAQgQgBgLgKg");
	this.shape_238.setTransform(157.2,56.2);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#1A1F71").s().p("AARAnIgHgQQgEgKgGgEQgFgEgJAAIgDAAIAAAiIgOAAIAAhNIAOAAIAAAiIADAAIAcgiIARAAIggAjQAPACAKAVIAIATg");
	this.shape_239.setTransform(146.9,56.1);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#1A1F71").s().p("AgaAeQgLgLAAgTQAAgSAMgLQAKgKAQAAQAQgBALALQAKALAAASQAAATgNAMQgKAKgPAAQgQgBgKgKgAgRgUQgFAJAAALQAAANAGAIQAHAJAJAAQAKAAAGgJQAIgIgBgNQAAgLgFgIQgGgKgMAAQgLAAgGAJg");
	this.shape_240.setTransform(138.2,56.2);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#1A1F71").s().p("AASAnIAAhBIgjAAIAABBIgOAAIAAhNIA/AAIAABNg");
	this.shape_241.setTransform(129.5,56.1);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#1A1F71").s().p("AgfAtQAHgDAFgFQAIgGAEgJIABgDIgBgEIgchGIAPAAIARAuIAEAOIAFgPIAQgtIAOAAIgVA3QgHATgGALQgFALgHAGQgJAIgIABg");
	this.shape_242.setTransform(121.4,57.9);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#1A1F71").s().p("AARAnIgHgQQgEgKgGgEQgFgEgJAAIgDAAIAAAiIgOAAIAAhNIAOAAIAAAiIADAAIAcgiIARAAIggAjQAPACAKAVIAIATg");
	this.shape_243.setTransform(114.3,56.1);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#1A1F71").s().p("AgaAeQgLgLAAgTQAAgSAMgLQAKgKAQAAQAQgBALALQAKALAAASQAAATgMAMQgLAKgPAAQgQgBgKgKgAgRgUQgFAJgBALQABANAGAIQAHAJAJAAQAKAAAHgJQAGgIAAgNQABgLgGgIQgGgKgMAAQgLAAgGAJg");
	this.shape_244.setTransform(105.6,56.2);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#1A1F71").s().p("AASAnIAAhBIgjAAIAABBIgOAAIAAhNIA/AAIAABNg");
	this.shape_245.setTransform(96.9,56.1);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#1A1F71").s().p("AAUAnIAAghIAAgfIAAAAIgNAYIgXAoIgQAAIAAhNIANAAIAAAhIgBAeIABAAIANgYIAXgnIAQAAIAABNg");
	this.shape_246.setTransform(84.8,56.1);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#1A1F71").s().p("AAUAnIAAghIABgfIgBAAIgNAYIgXAoIgQAAIAAhNIANAAIAAAhIgBAeIABAAIANgYIAWgnIARAAIAABNg");
	this.shape_247.setTransform(76,56.1);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#1A1F71").s().p("AASAnIAAgjIgjAAIAAAjIgOAAIAAhNIAOAAIAAAgIAjAAIAAggIAOAAIAABNg");
	this.shape_248.setTransform(67.2,56.1);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#1A1F71").s().p("AgXAeQgKgLAAgSQAAgRAKgMQAKgMAPABQARAAAJAMQAGAKAAAOIAAAGIg2AAQABANAHAHQAHAGALAAQAMAAAJgEIADAKQgLAGgPAAQgRgBgKgKgAAVgGQAAgKgEgFQgFgJgLAAQgJABgGAHQgFAHgBAJIApAAIAAAAg");
	this.shape_249.setTransform(58.8,56.2);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#1A1F71").s().p("AgvAnIAAhNIAOAAIAABCIAbAAIAAhCIANAAIAABCIAbAAIAAhCIAOAAIAABNg");
	this.shape_250.setTransform(48.9,56.1);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#1A1F71").s().p("AgkA3IAAhSIAAgaIANAAIABAOQAJgPARAAQAPAAAJAKQAJALAAASQAAATgLALQgKALgOAAQgQAAgHgNIAAAAIAAAqgAgNgmQgFAEgDAIIAAAGIAAANIAAAGQACAGAGAFQAGAEAHAAQALAAAFgIQAHgHAAgNQAAgNgGgIQgHgIgKAAQgHAAgGAFg");
	this.shape_251.setTransform(38.7,57.6);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#1A1F71").s().p("AgXAeQgKgLAAgSQAAgRAKgMQAKgMAPABQARAAAJAMQAGAKAAAOIAAAGIg2AAQABANAHAHQAHAGALAAQAMAAAJgEIADAKQgLAGgPAAQgRgBgKgKgAAVgGQAAgKgEgFQgFgJgLAAQgJABgGAHQgFAHgBAJIApAAIAAAAg");
	this.shape_252.setTransform(29.9,56.2);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#1A1F71").s().p("AgeAnIAAhMQAKgBAOAAQAiAAAAASQAAAIgFAEQgEAEgIACIAAAAQAJABAGAFQAFAFAAAHQAAAYgoAAIgVgBgAgRAdIALABQAXAAAAgOQAAgNgYAAIgKAAgAgRgdIAAAYIALAAQAUAAAAgNQAAgLgUAAg");
	this.shape_253.setTransform(22.2,56.2);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#1A1F71").s().p("AgaAeQgLgLAAgTQAAgSALgLQALgKAPAAQARgBAKALQALALAAASQAAATgMAMQgLAKgPAAQgQgBgKgKgAgRgUQgGAJAAALQAAANAHAIQAGAJAKAAQAKAAAHgJQAGgIABgNQAAgLgGgIQgHgKgLAAQgLAAgGAJg");
	this.shape_254.setTransform(13.6,56.2);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#1A1F71").s().p("AgTAeQgKgLAAgTQAAgQALgMQAMgLARAAQALAAAJADIgEAMQgGgFgKAAQgMAAgHAJQgHAIAAAMQAAANAHAIQAIAIAKAAQAJAAAJgEIADAKQgJAGgOAAQgRgBgKgKg");
	this.shape_255.setTransform(5.7,56.2);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#1A1F71").s().p("AATAnIAAghIABgfIAAAAIgNAYIgXAoIgQAAIAAhNIANAAIAAAhIAAAeIAAAAIAMgYIAYgnIAQAAIAABNg");
	this.shape_256.setTransform(258.5,34.1);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#1A1F71").s().p("AgjA3IAAhSIgBgaIAMAAIABAOQAKgPARAAQAOAAAJAKQAKALAAASQAAATgLALQgJALgPAAQgQAAgHgNIgBAAIAAAqgAgNgmQgFAEgCAIIgCAGIAAANIACAGQABAGAGAFQAGAEAHAAQAKAAAHgIQAGgHAAgNQAAgNgGgIQgGgIgLAAQgGAAgHAFg");
	this.shape_257.setTransform(249.7,35.6);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#1A1F71").s().p("AASAnIAAhBIgjAAIAABBIgOAAIAAhNIA/AAIAABNg");
	this.shape_258.setTransform(240.6,34.1);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#1A1F71").s().p("AgYAiQgGgHAAgJQAAgOAMgGQAMgIAVAAIAAgBQABgTgRABQgLAAgJAFIgEgJQAMgHANAAQAeAAAAAgIAAAcQAAAMABAGIgNAAIgBgKIgBAAQgHAMgPAAQgMAAgGgGgAgQARQAAAGAEAEQAEADAGAAQAFAAAFgEQAGgDABgGIABgFIAAgMIgCAAQgeAAAAARg");
	this.shape_259.setTransform(228.9,34.2);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#1A1F71").s().p("AAcAzIgBgZIg1AAIAAAZIgLAAIgBgjIAGAAQAFgIADgIQAFgNAAgRIAAgUIAyAAIAABCIAIAAIgBAjgAgHgbQAAAQgEAMQgCAIgEAHIAjAAIAAg3IgZAAg");
	this.shape_260.setTransform(220.8,35.4);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#1A1F71").s().p("AgaAdQgLgLAAgRQAAgSAMgMQAKgLAQAAQAQAAALAMQAKAKAAASQAAATgNALQgKAKgPAAQgQAAgKgLgAgRgTQgFAIAAALQAAAMAGAJQAHAIAJAAQAKAAAGgIQAIgJgBgMQAAgLgFgIQgGgKgMAAQgLAAgGAKg");
	this.shape_261.setTransform(212.4,34.2);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#1A1F71").s().p("AgXAnIAAhNIAvAAIAAAMIghAAIAABBg");
	this.shape_262.setTransform(205.4,34.1);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#1A1F71").s().p("AgZA2IAAgMIALAAQANgCAIgIQALgKADgSIgBAAQgJALgOAAQgOAAgJgJQgIgIAAgOQAAgPAKgKQAKgMAOAAQARAAAJAMQAJAMAAAUQAAAfgSARQgMAMgRACIgJABIgEAAgAgPgjQgFAHAAALQAAAKAFAGQAGAGAJAAQANAAAGgKQACgCAAgDQAAgOgFgJQgGgJgKAAQgIAAgHAHg");
	this.shape_263.setTransform(194.5,32.8);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#1A1F71").s().p("AADA0IAAhaIgQAKIgDgLIAVgMIANAAIAABng");
	this.shape_264.setTransform(185.5,32.8);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#1A1F71").s().p("AgZAoQgJgOAAgaQAAgZAKgOQAJgOAQAAQAQAAAJAOQAJAOAAAZQAAAZgJAOQgKAPgQAAQgQAAgJgOgAgOgfQgGAMAAATQAAAUAFAMQAGALAJAAQAVAAAAgrQAAgqgVAAQgJAAgFALg");
	this.shape_265.setTransform(178,32.8);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#1A1F71").s().p("AggA1IAAgIIALgLQAVgVAHgKQAKgMAAgKQAAgVgUAAQgLAAgLAIIgEgJQAMgLARAAQAPAAAIAKQAIAIAAAMQAAANgKANQgHALgSATIgIAHIAAAAIAtAAIAAAMg");
	this.shape_266.setTransform(169.7,32.7);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#1A1F71").s().p("AATAnIAAggIgKAAQgJAAgDAEQgDADgEAHIgEAMIgDAGIgPAAIAEgJIAGgMQADgHAEgEQAEgEAFAAIAAgBQgJgBgGgDQgGgGAAgIQAAgLALgGQAIgFAQAAIAZABIAABMgAgNgPQABAHAHADQAFADAHAAIAMAAIAAgaIgMgBQgTAAgBAOg");
	this.shape_267.setTransform(158,34.1);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#1A1F71").s().p("AgjA3IAAhSIgBgaIAMAAIABAOQAKgPARAAQAOAAAKAKQAJALAAASQAAATgLALQgJALgPAAQgQAAgHgNIgBAAIAAAqgAgNgmQgFAEgDAIIgBAGIAAANIABAGQACAGAGAFQAGAEAHAAQAKAAAHgIQAGgHAAgNQAAgNgGgIQgGgIgLAAQgGAAgHAFg");
	this.shape_268.setTransform(150.2,35.6);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#1A1F71").s().p("AgYAiQgGgHAAgJQAAgOAMgGQAMgIAVAAIAAgBQAAgTgQABQgLAAgJAFIgDgJQAKgHAOAAQAdAAABAgIAAAcQgBAMACAGIgNAAIgBgKIgBAAQgHAMgPAAQgLAAgHgGgAgQARQAAAGAEAEQAEADAFAAQAHAAAEgEQAGgDABgGIABgFIAAgMIgCAAQgeAAAAARg");
	this.shape_269.setTransform(141.3,34.2);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#1A1F71").s().p("AgeAmIAAhLQAKgBAOAAQAigBAAAUQAAAGgFAFQgEAFgIABIAAABQAJABAGADQAFAGAAAIQAAAWgoAAIgVgBgAgRAdIALABQAXAAAAgNQAAgOgYAAIgKAAgAgRgcIAAAWIALAAQAUABAAgMQAAgMgUAAg");
	this.shape_270.setTransform(133.9,34.2);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#1A1F71").s().p("AASAnIAAgjIgjAAIAAAjIgOAAIAAhNIAOAAIAAAgIAjAAIAAggIAOAAIAABNg");
	this.shape_271.setTransform(125.3,34.1);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#1A1F71").s().p("AATAnIAAggIgKAAQgJAAgDAEQgDADgEAHIgEAMIgDAGIgPAAIAEgJIAGgMQADgHAEgEQAEgEAFAAIAAgBQgJgBgGgDQgGgGAAgIQAAgLALgGQAIgFAQAAIAZABIAABMgAgNgPQABAHAHADQAFADAHAAIAMAAIAAgaIgMgBQgTAAgBAOg");
	this.shape_272.setTransform(116.6,34.1);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#1A1F71").s().p("AADA0IAAhaIgRAKIgDgLIAXgMIAMAAIAABng");
	this.shape_273.setTransform(104.9,32.8);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#1A1F71").s().p("AgfAuIADgKQALAHANAAQALgBAGgGQAGgGgBgIQAAgKgIgFQgHgGgLAAIgHAAIAAgJIAHAAQAIAAAGgFQAJgEgBgJQAAgHgEgDQgFgGgIAAQgLAAgJAIIgFgKQAMgJAQAAQANAAAJAIQAGAHABAKQAAASgTAGIAAABQAJACAHAFQAGAIAAAKQAAAOgJAJQgKAJgRAAQgQAAgLgIg");
	this.shape_274.setTransform(97.2,32.8);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#1A1F71").s().p("AgaAdQgLgLAAgRQAAgSAMgMQAKgLAQAAQAQAAALAMQAKAKAAASQAAATgNALQgKAKgPAAQgQAAgKgLgAgRgTQgFAIAAALQAAAMAGAJQAHAIAJAAQAKAAAGgIQAIgJgBgMQABgLgGgIQgGgKgMAAQgKAAgHAKg");
	this.shape_275.setTransform(85.6,34.2);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#1A1F71").s().p("AASAnIAAhBIgjAAIAABBIgOAAIAAhNIA/AAIAABNg");
	this.shape_276.setTransform(76.9,34.1);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#1A1F71").s().p("AgYAiQgGgHAAgJQAAgOAMgGQAMgIAVAAIAAgBQAAgTgQABQgLAAgJAFIgDgJQAKgHAOAAQAeAAAAAgIAAAcQAAAMABAGIgNAAIgBgKIgBAAQgHAMgPAAQgLAAgHgGgAgQARQAAAGAEAEQAEADAFAAQAHAAAEgEQAFgDACgGIABgFIAAgMIgCAAQgeAAAAARg");
	this.shape_277.setTransform(65.2,34.2);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#1A1F71").s().p("AAbAzIAAgZIg1AAIAAAZIgLAAIgBgjIAGAAQAFgIADgIQAFgNAAgRIAAgUIAyAAIAABCIAIAAIgBAjgAgHgbQAAAQgEAMQgCAIgEAHIAjAAIAAg3IgZAAg");
	this.shape_278.setTransform(57.1,35.4);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#1A1F71").s().p("AgaAdQgLgLAAgRQAAgSAMgMQAKgLAQAAQAQAAALAMQAKAKAAASQAAATgNALQgKAKgPAAQgQAAgKgLgAgRgTQgFAIgBALQABAMAGAJQAHAIAJAAQAKAAAGgIQAIgJgBgMQABgLgGgIQgGgKgMAAQgKAAgHAKg");
	this.shape_279.setTransform(48.7,34.2);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#1A1F71").s().p("AgXAnIAAhNIAvAAIAAAMIghAAIAABBg");
	this.shape_280.setTransform(41.7,34.1);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#1A1F71").s().p("AgZAtQgJgIAAgLQAAgUAUgHIAAAAQgQgJAAgPQAAgMAJgIQAJgIANAAQAOAAAJAIQAHAIAAAKQAAAQgRAIIAAABQAVAHAAATQAAANgKAIQgKAJgPAAQgPAAgKgJgAgUAYQAAAIAGAFQAFAHAJAAQAKgBAFgFQAGgFAAgIQAAgRgWgGQgSAFgBARgAgMglQgFAEAAAHQAAAOATAFQAQgFAAgOQAAgHgEgEQgFgGgIAAQgIAAgFAGg");
	this.shape_281.setTransform(30.7,32.8);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#1A1F71").s().p("AADA0IAAhaIgRAKIgCgLIAVgMIANAAIAABng");
	this.shape_282.setTransform(21.8,32.8);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#1A1F71").s().p("AgZAoQgJgOAAgaQAAgZAKgOQAJgOAQAAQAQAAAJAOQAJAOAAAZQAAAZgJAOQgKAPgQAAQgQAAgJgOgAgOgfQgGAMAAATQAAAUAFAMQAGALAJAAQAVAAAAgrQAAgqgVAAQgJAAgFALg");
	this.shape_283.setTransform(14.3,32.8);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#1A1F71").s().p("AggA1IAAgIIALgLQAVgVAHgKQAKgMAAgKQAAgVgUAAQgLAAgLAIIgEgJQAMgLARAAQAPAAAIAKQAIAIAAAMQAAANgKANQgHALgSATIgIAHIAAAAIAtAAIAAAMg");
	this.shape_284.setTransform(6,32.7);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#1A1F71").s().p("AATAnIAAggIgKAAQgIAAgEAEQgDADgDAHIgFAMIgDAGIgPAAIAFgJIAEgMQADgHAFgEQAEgEAFAAIAAgBQgJgBgGgDQgGgGAAgIQAAgLALgGQAIgFAQAAIAZABIAABMgAgNgPQAAAHAIADQAFADAIAAIALAAIAAgaIgLgBQgVAAAAAOg");
	this.shape_285.setTransform(260.8,12.1);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#1A1F71").s().p("AgjA3IAAhSIgBgaIAMAAIABAOQAKgPARAAQAOAAAJAKQAKALAAASQAAATgLALQgJALgPAAQgPAAgIgNIAAAAIAAAqgAgMgmQgHAEgBAIIgBAGIAAANIABAGQABAGAGAFQAGAEAHAAQAKAAAHgIQAGgHAAgNQAAgNgGgIQgHgIgKAAQgHAAgFAFg");
	this.shape_286.setTransform(253,13.6);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#1A1F71").s().p("AgbAqQgIgNAAgWQAAgbAMgPQAKgPAWgDIAUgFIgBAMIgQAEQgTADgIALQgHALgBAPIAAAAQAEgIAHgFQAIgFAHAAQAPAAAJAKQAJAKAAASQAAATgJALQgKALgRAAQgSAAgJgRgAgQAAQgEAHAAAKQAAALAFAJQAGALAKAAQAKAAAGgJQAEgIAAgMQAAgMgEgHQgFgJgMAAQgLAAgFAJg");
	this.shape_287.setTransform(244,10.3);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#1A1F71").s().p("AgYAhQgGgGAAgJQAAgOAMgHQAMgHAVAAIAAgCQAAgRgQgBQgLAAgJAHIgDgKQAKgGAOgBQAeABAAAfIAAAcQAAALABAIIgNAAIgBgKIgBAAQgHAMgPgBQgLABgHgIgAgQAQQAAAHAEADQAEAEAFAAQAHAAAEgEQAFgDACgGIABgEIAAgNIgCAAQgeAAAAAQg");
	this.shape_288.setTransform(235.7,12.2);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#1A1F71").s().p("AARAnIgHgQQgEgKgGgEQgFgEgJAAIgDAAIAAAiIgOAAIAAhNIAOAAIAAAiIADAAIAcgiIARAAIggAjQAPACAKAVIAIATg");
	this.shape_289.setTransform(228.8,12.1);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#1A1F71").s().p("AgXAeQgKgLAAgSQAAgRAKgMQAKgMAPAAQARAAAJANQAGAKAAAOIAAAGIg2AAQABANAHAHQAHAGALAAQAMAAAJgEIADAKQgLAGgPgBQgRABgKgLgAAVgGQAAgKgEgGQgFgIgLAAQgJABgGAHQgFAHgBAJIApAAIAAAAg");
	this.shape_290.setTransform(220.4,12.2);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#1A1F71").s().p("AAbAzIgBgYIg0AAIgBAYIgKAAIgBgjIAGAAQAGgHACgJQAEgNABgRIAAgUIAyAAIAABCIAIAAIgBAjgAgHgaQAAAPgEANQgCAHgEAHIAjAAIAAg3IgZAAg");
	this.shape_291.setTransform(212,13.4);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#1A1F71").s().p("AggAvIAEgLQAKAFAMAAQAKAAAHgFQAHgHAAgKQAAgLgHgFQgIgGgOAAIgOABIAHgyIAwAAIAAAMIgnAAIgDAaIAIAAQAMAAAKAGQAPAIAAASQAAAPgMAJQgKALgRAAQgQAAgKgGg");
	this.shape_292.setTransform(200.3,10.9);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#1A1F71").s().p("AAEA0IAAhaIgRAKIgEgLIAWgMIAMAAIAABng");
	this.shape_293.setTransform(191.6,10.8);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#1A1F71").s().p("AgTAeQgLgMAAgRQAAgSAMgLQAMgMARAAQALAAAJAEIgDAMQgHgFgKAAQgLAAgIAJQgHAIAAAMQAAANAIAIQAHAIALAAQAIAAAJgEIADAKQgKAGgNgBQgQABgLgLg");
	this.shape_294.setTransform(181.4,12.2);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#1A1F71").s().p("AgGAnIAAhBIgYAAIAAgMIA9AAIAAAMIgYAAIAABBg");
	this.shape_295.setTransform(171.1,12.1);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#1A1F71").s().p("AgKAfQgIgKgCgRIgNAAIAAAjIgOAAIAAhNIAOAAIAAAhIANAAQACgQAJgJQAJgKAOAAQAPAAAKALQAIAMABARQgBARgJAMQgKALgPAAQgNABgKgKgAgBgUQgGAIABANQAAALAEAJQAGAJAJAAQAKAAAGgKQAEgIAAgMQAAgLgEgJQgGgJgJAAQgLAAgEAJg");
	this.shape_296.setTransform(162.5,12.2);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#1A1F71").s().p("AgfAtQAHgDAFgFQAIgFAEgKIABgEIgBgDIgchGIAPAAIARAuIAEAOIAFgPIAQgtIAOAAIgVA3QgHATgGALQgFALgHAGQgJAIgIABg");
	this.shape_297.setTransform(152.8,13.9);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#1A1F71").s().p("AgeAnIAAhMQAKgBAOgBQAiABAAASQAAAIgFAEQgEAEgIACIAAAAQAJACAGAEQAFAFAAAHQAAAYgoAAIgVgBgAgRAdIALABQAXAAAAgOQAAgNgYAAIgKAAgAgRgdIAAAYIALAAQAUgBAAgMQAAgLgUAAg");
	this.shape_298.setTransform(145.3,12.2);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#1A1F71").s().p("AgGAnIAAhBIgYAAIAAgMIA9AAIAAAMIgYAAIAABBg");
	this.shape_299.setTransform(137.8,12.1);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#1A1F71").s().p("AgTAeQgKgMAAgRQAAgSALgLQALgMASAAQAMAAAHAEIgDAMQgGgFgKAAQgMAAgHAJQgHAIAAAMQAAANAHAIQAIAIAKAAQAKAAAIgEIACAKQgIAGgOgBQgRABgKgLg");
	this.shape_300.setTransform(131,12.2);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#1A1F71").s().p("AAUA3IAAgiIABgeIgBAAIgNAXIgXApIgQAAIAAhNIANAAIAAAgIgBAfIABAAIANgYIAWgnIARAAIAABNgAgUg1IAKAAQABAMAJgBQAJABABgMIALAAQgBATgUABQgTgBgBgTg");
	this.shape_301.setTransform(123,10.6);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#1A1F71").s().p("AgXAeQgKgLAAgSQAAgRAKgMQAKgMAPAAQARAAAJANQAGAKAAAOIAAAGIg2AAQABANAHAHQAHAGALAAQAMAAAJgEIADAKQgLAGgPgBQgRABgKgLgAAVgGQAAgKgEgGQgFgIgLAAQgJABgGAHQgFAHgBAJIApAAIAAAAg");
	this.shape_302.setTransform(114.5,12.2);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#1A1F71").s().p("AAbAzIgBgYIg0AAIgBAYIgLAAIAAgjIAHAAQAEgHADgJQAEgNAAgRIAAgUIAzAAIAABCIAIAAIAAAjgAgHgaQAAAPgEANQgCAHgEAHIAiAAIAAg3IgYAAg");
	this.shape_303.setTransform(106.1,13.4);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#1A1F71").s().p("AATAnIAAggIgKAAQgIAAgEAEQgEADgDAHIgEAMIgDAGIgPAAIAEgJIAGgMQADgHAEgEQAEgEAEAAIAAgBQgIgBgFgDQgHgGAAgIQAAgLAKgGQAJgFAQAAIAZABIAABMgAgMgPQAAAHAHADQAFADAHAAIAMAAIAAgaIgMgBQgTAAAAAOg");
	this.shape_304.setTransform(94.3,12.1);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#1A1F71").s().p("AAUAnIAAghIABgfIgBAAIgNAYIgXAoIgQAAIAAhNIANAAIAAAhIgBAeIABAAIANgYIAWgnIARAAIAABNg");
	this.shape_305.setTransform(86.4,12.1);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#1A1F71").s().p("AASAnIAAgjIgjAAIAAAjIgOAAIAAhNIAOAAIAAAgIAjAAIAAggIAOAAIAABNg");
	this.shape_306.setTransform(77.6,12.1);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#1A1F71").s().p("AgXAeQgKgLAAgSQAAgRAKgMQAKgMAPAAQARAAAJANQAGAKAAAOIAAAGIg2AAQABANAHAHQAHAGALAAQAMAAAJgEIADAKQgLAGgPgBQgRABgKgLgAAVgGQAAgKgEgGQgFgIgLAAQgJABgGAHQgFAHgBAJIApAAIAAAAg");
	this.shape_307.setTransform(69.3,12.2);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#1A1F71").s().p("AAmAnIgHgSQgGgQgQAAIgDAAIAAAiIgMAAIAAgiIgCAAQgJAAgFADQgFAEgEAJIgHASIgNAAIAIgWQAHgSAQgCIgegjIAQAAIAaAiIACAAIAAgiIAMAAIAAAiIAEAAIAZgiIAQAAIgeAjQAPACAIASIAIAWg");
	this.shape_308.setTransform(60,12.1);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#1A1F71").s().p("AgaAeQgLgMAAgRQAAgSAMgMQAKgLAQAAQAQAAALALQAKAMAAARQAAATgMAMQgLAKgPgBQgQABgKgLgAgRgUQgFAJgBALQABANAGAIQAHAJAJAAQAKAAAHgJQAGgIAAgNQABgLgGgIQgGgKgMAAQgLAAgGAJg");
	this.shape_309.setTransform(50.3,12.2);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#1A1F71").s().p("AgiAcQAFAAADgDQAFgEABgIQACgHAAgNIAAgfIA1AAIAABMIgOAAIAAhBIgaAAIAAAUQAAARgCAJQgDALgHAEQgGAFgJAAg");
	this.shape_310.setTransform(41.3,12.2);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#1A1F71").s().p("AAbAzIgBgYIg0AAIAAAYIgLAAIgBgjIAGAAQAGgHACgJQAEgNABgRIAAgUIAyAAIAABCIAIAAIgBAjgAgHgaQAAAPgEANQgCAHgEAHIAiAAIAAg3IgYAAg");
	this.shape_311.setTransform(33.4,13.4);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#1A1F71").s().p("AgXAeQgKgLAAgSQAAgRAKgMQAKgMAPAAQARAAAJANQAGAKAAAOIAAAGIg2AAQABANAHAHQAHAGALAAQAMAAAJgEIADAKQgLAGgPgBQgRABgKgLgAAVgGQAAgKgEgGQgFgIgLAAQgJABgGAHQgFAHgBAJIApAAIAAAAg");
	this.shape_312.setTransform(25.3,12.2);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#1A1F71").s().p("AgkA3IAAhSIAAgaIANAAIABAOQAJgPARAAQAPAAAIAKQAKALAAASQAAATgLALQgKALgOAAQgPAAgIgNIAAAAIAAAqgAgMgmQgHAEgCAIIAAAGIAAANIAAAGQACAGAGAFQAGAEAHAAQALAAAFgIQAHgHAAgNQAAgNgGgIQgHgIgKAAQgHAAgFAFg");
	this.shape_313.setTransform(17,13.6);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#1A1F71").s().p("AAZA2IAAhfIgxAAIAABfIgOAAIAAhrIBNAAIAABrg");
	this.shape_314.setTransform(7.1,10.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_314},{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302},{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol28, new cjs.Rectangle(0,2,269,262), null);


(lib.Symbol24hjj = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.hand();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol24hjj, new cjs.Rectangle(0,0,168,76), null);


(lib.Symbol23cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1E1D73").s().p("AghApQgNgPAAgYQAAgYANgQQAOgRAWAAQAXAAAMASQAJAOAAASIgBAJIhJAAQgBASALAKQAKAIAPAAQARAAAMgFIAEAOQgQAHgUAAQgXAAgPgPgAgTgeQgHAJgBAMIA3AAQABgMgGgJQgHgLgPAAQgMAAgIALg");
	this.shape.setTransform(153.5,23.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1E1D73").s().p("AghApQgNgPAAgYQAAgYANgQQAOgRAWAAQAXAAAMASQAJAOAAASIgBAJIhJAAQAAASALAKQAJAIAPAAQAQAAAOgFIACAOQgPAHgUAAQgXAAgPgPgAgTgeQgHAJgBAMIA3AAQAAgMgFgJQgHgLgPAAQgMAAgIALg");
	this.shape_1.setTransform(142.5,23.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E1D73").s().p("AAZA1IAAgwIgxAAIAAAwIgTAAIAAhpIATAAIAAArIAxAAIAAgrIATAAIAABpg");
	this.shape_2.setTransform(131,23.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E1D73").s().p("AgmA6QgLgSAAgfQABgkAQgWQAOgTAegGQATgDAIgCIgBAQQgHACgPACQgaAEgLARQgKAOgCAUIABAAQAFgLAKgGQALgGAKAAQAUAAAMANQANAOAAAYQAAAagNAPQgNAPgXABQgZAAgNgXgAgXAAQgGAKABANQAAAPAGANQAJAPANAAQAPAAAIgNQAGgKAAgRQAAgQgFgKQgIgNgQAAQgQAAgHANg");
	this.shape_3.setTransform(119.2,21.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#1E1D73").s().p("AglApQgOgPAAgZQAAgZAPgQQAPgPAVAAQAYAAAOAQQAOAPAAAYQAAAbgRAPQgPAOgUAAQgWAAgPgPgAgXgbQgIALAAAQQAAASAJALQAIAMAOAAQAOAAAJgLQAJgMAAgSQAAgPgHgLQgJgOgQAAQgPAAgIANg");
	this.shape_4.setTransform(107.4,23.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1E1D73").s().p("AgxBMIAAhyIgBgjIASAAIABATIAAAAQAMgVAZAAQATAAANAPQANAPAAAYQAAAagPAQQgOAOgTAAQgWAAgLgRIAAAAIAAA6gAgSg1QgIAHgDAKIgBAIIAAASIABAIQADAJAHAHQAJAGAKAAQAOAAAJgLQAIgLAAgSQABgRgJgLQgIgMgPAAQgJAAgJAHg");
	this.shape_5.setTransform(95.4,25.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1E1D73").s().p("AAmBGIgBgiIhJAAIgBAiIgPAAIgBgwIAJAAQAHgKAEgMQAGgTAAgWIAAgcIBGAAIAABbIALAAIgBAwgAgKglQAAAVgFASQgDAJgGALIAwAAIAAhMIgiAAg");
	this.shape_6.setTransform(82.7,25.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1E1D73").s().p("AgkApQgPgPAAgZQAAgZAPgQQAPgPAVAAQAYAAAOAQQAOAPAAAYQAAAbgRAPQgPAOgUAAQgWAAgOgPgAgYgbQgHALgBAQQABASAIALQAJAMAOAAQANAAAKgLQAJgMAAgSQAAgPgHgLQgJgOgQAAQgPAAgJANg");
	this.shape_7.setTransform(71.2,23.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1E1D73").s().p("AAiBKIAAiDIhEAAIAACDIgTAAIAAiTIBrAAIAACTg");
	this.shape_8.setTransform(58.1,21.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AghApQgNgPAAgYQAAgYANgQQAOgRAWAAQAXAAAMASQAJAOAAASIgBAJIhJAAQgBASALAKQAKAIAPAAQARAAAMgFIAEAOQgQAHgUAAQgXAAgPgPgAgTgeQgHAJgBAMIA3AAQABgMgGgJQgHgLgPAAQgMAAgIALg");
	this.shape_9.setTransform(153.5,23.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AghApQgNgPAAgYQAAgYANgQQAOgRAWAAQAXAAAMASQAJAOAAASIgBAJIhJAAQAAASALAKQAJAIAPAAQAQAAAOgFIACAOQgPAHgUAAQgXAAgPgPgAgTgeQgHAJgBAMIA3AAQAAgMgFgJQgHgLgPAAQgMAAgIALg");
	this.shape_10.setTransform(142.5,23.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAZA1IAAgwIgxAAIAAAwIgTAAIAAhpIATAAIAAArIAxAAIAAgrIATAAIAABpg");
	this.shape_11.setTransform(131,23.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgmA6QgLgSAAgfQABgkAQgWQAOgTAegGQATgDAIgCIgBAQQgHACgPACQgaAEgLARQgKAOgCAUIABAAQAFgLAKgGQALgGAKAAQAUAAAMANQANAOAAAYQAAAagNAPQgNAPgXABQgZAAgNgXgAgXAAQgGAKABANQAAAPAGANQAJAPANAAQAPAAAIgNQAGgKAAgRQAAgQgFgKQgIgNgQAAQgQAAgHANg");
	this.shape_12.setTransform(119.2,21.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AglApQgOgPAAgZQAAgZAPgQQAPgPAVAAQAYAAAOAQQAOAPAAAYQAAAbgRAPQgPAOgUAAQgWAAgPgPgAgXgbQgIALAAAQQAAASAJALQAIAMAOAAQAOAAAJgLQAJgMAAgSQAAgPgHgLQgJgOgQAAQgPAAgIANg");
	this.shape_13.setTransform(107.4,23.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgxBMIAAhyIgBgjIASAAIABATIAAAAQAMgVAZAAQATAAANAPQANAPAAAYQAAAagPAQQgOAOgTAAQgWAAgLgRIAAAAIAAA6gAgSg1QgIAHgDAKIgBAIIAAASIABAIQADAJAHAHQAJAGAKAAQAOAAAJgLQAIgLAAgSQABgRgJgLQgIgMgPAAQgJAAgJAHg");
	this.shape_14.setTransform(95.4,25.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAmBGIgBgiIhJAAIgBAiIgPAAIgBgwIAJAAQAHgKAEgMQAGgTAAgWIAAgcIBGAAIAABbIALAAIgBAwgAgKglQAAAVgFASQgDAJgGALIAwAAIAAhMIgiAAg");
	this.shape_15.setTransform(82.7,25.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgkApQgPgPAAgZQAAgZAPgQQAPgPAVAAQAYAAAOAQQAOAPAAAYQAAAbgRAPQgPAOgUAAQgWAAgOgPgAgYgbQgHALgBAQQABASAIALQAJAMAOAAQANAAAKgLQAJgMAAgSQAAgPgHgLQgJgOgQAAQgPAAgJANg");
	this.shape_16.setTransform(71.2,23.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAiBKIAAiDIhEAAIAACDIgTAAIAAiTIBrAAIAACTg");
	this.shape_17.setTransform(58.1,21.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]},1).to({state:[]},2).wait(1));

	// Layer_4
	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#F7B423").s().p("AuJDpQiQAAAAiQIAAiyQAAiQCQABIcUAAQCPgBAACQIAACyQAACQiPAAg");
	this.shape_18.setTransform(104.7,23);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#1E1D73").s().p("AuJDpQiQAAAAiQIAAiyQAAiQCQABIcUAAQCPgBAACQIAACyQAACQiPAAg");
	this.shape_19.setTransform(104.7,23);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18}]}).to({state:[{t:this.shape_19}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,-0.4,210.4,46.7);


(lib.Symbol23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#000000","rgba(0,0,0,0)"],[0.247,1],0,0,0,0,0,49.6).s().p("AlZFcQiQiQAAjMQAAjLCQiQQCOiPDLAAQDLAACPCPQCQCQAADLQAADMiQCQQiPCPjLAAQjLAAiOiPg");
	this.shape.setTransform(49,49.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol23, new cjs.Rectangle(0,0,97.9,98.2), null);


(lib.Symbol20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.face();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol20, new cjs.Rectangle(0,0,62,126), null);


(lib.Symbol19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AglBKIAAiTIBIAAIAAAJIg+AAIAAA5IA6AAIAAAIIg6AAIAABAIBBAAIAAAJg");
	this.shape.setTransform(108.9,11.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AghA6QgVgUAAglQAAghAUgVQAVgXAhAAQAWAAANAHIgEAIQgNgFgSgBQgdAAgRASQgRATAAAfQAAAeAQASQARASAdAAQATAAAOgGIADAHQgPAIgZAAQgcABgUgTg");
	this.shape_1.setTransform(97.1,11.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgpBKIAAiRQANgDARAAQAZAAANAMQAJAJAAAPQAAAMgHAJQgHAJgMAEIAAAAQAMADAJAHQALALAAAQQAAARgLALQgOAOggAAIgagBgAgeBBQAFACANAAQASAAALgIQAOgIAAgSQAAgQgNgJQgMgIgSAAIgSAAgAgehAIAAA4IAVAAQAPAAAKgIQAJgIAAgNQAAgcgkAAQgOAAgFABg");
	this.shape_2.setTransform(85.6,11.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEBKIAAiKIgxAAIAAgJIBrAAIAAAJIgxAAIAACKg");
	this.shape_3.setTransform(69.7,11.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AglBKIAAiTIBIAAIAAAJIg+AAIAAA5IA7AAIAAAIIg7AAIAABAIBBAAIAAAJg");
	this.shape_4.setTransform(60,11.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAjBLIAAhEIgSAAQgRAAgHAIQgGAHgGARIgJAaIgEAKIgMAAIAFgMIAKgcQAGgQAIgIQAGgGAHgCIAAAAQgPgCgKgJQgJgLAAgOQAAgTAMgKQAOgMAYAAQARAAAOADIAACSgAgagiQAAAQAMAIQAMAJASAAIATAAIAAg+QgJgCgMAAQgoAAAAAfg");
	this.shape_5.setTransform(48.1,11);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AApBKIAAhKIhRAAIAABKIgKAAIAAiTIAKAAIAABBIBRAAIAAhBIAKAAIAACTg");
	this.shape_6.setTransform(36.3,11.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgmBKIAAiTIBJAAIAAAJIg+AAIAAA5IA6AAIAAAIIg6AAIAABAIBCAAIAAAJg");
	this.shape_7.setTransform(24.8,11.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AA+BKIgFhHQgDguAAgSIgBAAIgTA3IggBQIgGAAIgdhOQgPgogEgRIgBAAQAAAegDAlIgFBEIgKAAIALiTIAMAAIAgBUIAQAwIAAAAQAEgQAMggIAhhUIANAAIAKCTg");
	this.shape_8.setTransform(10.6,11.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol19, new cjs.Rectangle(0,0,300,26), null);


(lib.Symbol17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgpBKIAAiUIAKAAIAAA6IATgBQAXAAAOALQARAKAAAXQABATgLAMQgQARggAAIgZgBgAgfgHIAABIIASABQATAAAMgJQAOgLAAgTQgBgTgOgIQgMgIgSAAg");
	this.shape.setTransform(134.4,11.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAjBKIAAhAIgBAAQgQAKgUAAQgqAAAAgrIAAgyIAKAAIAAAxQAAAjAjAAQASAAAQgKIAAhKIAKAAIAACTg");
	this.shape_1.setTransform(122,11.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AguA4QgSgUAAgiQAAgjATgWQASgUAcgBQAcAAASAVQASAUAAAjQAAAjgUAWQgSATgbAAQgcABgSgVgAgogtQgOASAAAcQAAAbAOATQAQAUAYAAQAZAAAQgUQAOgTAAgcQAAgagNgTQgQgWgaAAQgZAAgPAWg");
	this.shape_2.setTransform(108.4,11.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag1BCQAIgBAHgGQAOgOAAg6IAAg9IBOAAIAACTIgLAAIAAiKIg5AAIAAAzQAAAfgCAOQgEAbgNAKQgKAHgJAAg");
	this.shape_3.setTransform(93.9,11.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgmBKIAAiTIBJAAIAAAJIg+AAIAAA5IA7AAIAAAIIg7AAIAABAIBCAAIAAAJg");
	this.shape_4.setTransform(84.1,11.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AA+BKIgFhHQgDguAAgSIgBAAIgTA3IggBQIgGAAIgdhOQgPgogEgRIgBAAQAAAegDAlIgFBEIgKAAIALiTIAMAAIAgBUIAQAwIAAAAQAEgQAMggIAhhUIANAAIAKCTg");
	this.shape_5.setTransform(69.9,11.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAwBKIgTg0Ig6AAIgSA0IgLAAIA2iTIAJAAIA2CTgAAaANIgSgwIgIgaIAAAAIgHAaIgSAwIAzAAg");
	this.shape_6.setTransform(50.2,11.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AApBKIAAhKIhRAAIAABKIgKAAIAAiTIAKAAIAABBIBRAAIAAhBIAKAAIAACTg");
	this.shape_7.setTransform(36.7,11.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAyBbIgBgiIhhAAIgBAiIgIAAIgCgrIALAAQAMgZADgIQAHgYAAgtIAAglIBKAAIAACLIAMAAIgBArgAgQgxQAAArgIAYQgDALgKATIBKAAIAAiCIg1AAg");
	this.shape_8.setTransform(22.9,12.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AguA4QgSgUAAgiQAAgjATgWQASgUAcgBQAcAAASAVQASAUAAAjQAAAjgUAWQgSATgbAAQgcABgSgVgAgogtQgOASAAAcQAAAbAOATQAQAUAYAAQAZAAAQgUQAOgTAAgcQAAgagNgTQgQgWgaAAQgZAAgPAWg");
	this.shape_9.setTransform(9.4,11.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol17, new cjs.Rectangle(0,0,300,26), null);


(lib.Symbol16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgXbAnEMAAAhOHMAu3AAAMAAABOHg");
	this.shape.setTransform(150,250);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol16, new cjs.Rectangle(0,0,300,500), null);


(lib.Symbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1A1E5A").s().p("AAAAIQgDAAgCgDQgCgCABgDQAAgHAGAAQAHAAAAAHQAAADgCACQgCADgDAAg");
	this.shape.setTransform(220.2,9.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1A1E5A").s().p("AAZArIAAgrIABghIgSAdIggAvIgJAAIAAhVIAJAAIAAAqIgBAiIAAAAIARgcIAhgwIAJAAIAABVg");
	this.shape_1.setTransform(213.7,6.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1A1E5A").s().p("AAXArIgIgQQgGgNgIgGQgHgFgNAAIgEAAIAAAoIgIAAIAAhVIAIAAIAAAnIAFAAIAmgnIALAAIgoAoQALABAIAGQAHAGAHAOIAIASg");
	this.shape_2.setTransform(205.6,6.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1A1E5A").s().p("AgmA+IAAheIAAgbIAIAAIAAARIABAAQAKgTAVAAQARAAAKAMQAKANAAATQAAAVgMANQgLALgQABQgUgBgJgQIAAAAIAAAygAgQgwQgJAHgDAKIgBAIIAAARIAAAGQAEAJAIAGQAHAHAKgBQAOABAIgLQAIgLAAgRQABgPgJgKQgIgMgOAAQgJAAgHAGg");
	this.shape_3.setTransform(196.3,7.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#1A1E5A").s().p("AgYAmQgGgHAAgKQAAgPANgHQAOgIAZAAIAAgCQAAgagWAAQgMAAgJAHIgDgHQALgHANAAQAeAAAAAiIAAAhQAAALABAJIgIAAIgBgMIAAAAQgEAGgGAEQgIAEgJAAQgMAAgHgHgAgVAUQAAAJAFAFQAFAEAHAAQASAAAHgRIABgFIAAgSIgFAAQgmAAAAAWg");
	this.shape_4.setTransform(186.7,6.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1A1E5A").s().p("AAhA5IgBgbIg+AAIgBAbIgHAAIgBgiIAHAAQAGgJADgJQAFgRAAgUIAAgYIAyAAIAABPIAIAAIAAAigAgKggQAAAWgFAQQgCAGgGALIAuAAIAAhIIghAAg");
	this.shape_5.setTransform(178.1,7.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1A1E5A").s().p("AgcAhQgMgMABgUQAAgVAMgMQAMgMAPAAQASAAALAMQAMAMAAAUQAAAWgOAMQgLALgQAAQgRAAgLgMgAgXgZQgIALAAAOQAAAQAJALQAJALANAAQANAAAKgLQAIgLABgQQgBgNgGgLQgKgNgPAAQgPAAgIAMg");
	this.shape_6.setTransform(169.3,6.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1A1E5A").s().p("AAZArIAAhOIgxAAIAABOIgIAAIAAhVIBBAAIAABVg");
	this.shape_7.setTransform(159.8,6.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1A1E5A").s().p("AAZArIAAgrIABghIgSAdIgfAvIgKAAIAAhVIAJAAIAAAqIgBAiIABAAIAQgcIAggwIAJAAIAABVg");
	this.shape_8.setTransform(146.5,6.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1A1E5A").s().p("AAZArIAAgrIABghIgSAdIggAvIgJAAIAAhVIAJAAIAAAqIgBAiIAAAAIARgcIAhgwIAJAAIAABVg");
	this.shape_9.setTransform(133.1,6.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1A1E5A").s().p("AAXArIgIgQQgGgNgIgGQgHgFgNAAIgEAAIAAAoIgIAAIAAhVIAIAAIAAAnIAFAAIAmgnIALAAIgoAoQALABAIAGQAHAGAHAOIAIASg");
	this.shape_10.setTransform(124.9,6.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1A1E5A").s().p("AAhA5IgBgbIg+AAIgBAbIgHAAIgBgiIAHAAQAGgJADgJQAFgRAAgUIAAgYIAyAAIAABPIAIAAIAAAigAgKggQAAAWgFAQQgCAGgGALIAuAAIAAhIIghAAg");
	this.shape_11.setTransform(115.5,7.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#1A1E5A").s().p("AAZArIAAgrIABghIgSAdIgfAvIgJAAIAAhVIAIAAIAAAqIgBAiIABAAIAQgcIAggwIAJAAIAABVg");
	this.shape_12.setTransform(106.7,6.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#1A1E5A").s().p("AAXArIgIgQQgGgNgIgGQgHgFgNAAIgEAAIAAAoIgIAAIAAhVIAIAAIAAAnIAFAAIAmgnIALAAIgoAoQALABAIAGQAHAGAHAOIAIASg");
	this.shape_13.setTransform(98.5,6.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#1A1E5A").s().p("AgVAhQgMgMAAgUQAAgUANgMQAMgNATAAQAPAAAIAFIgEAHQgJgFgLAAQgQAAgJAMQgJAKAAAPQAAARAJALQAKAKAOAAQAKAAAMgFIACAGQgLAGgOAAQgRAAgMgMg");
	this.shape_14.setTransform(90,6.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#1A1E5A").s().p("AAZA9IAAgrIABgiIgSAdIgfAwIgJAAIAAhWIAIAAIAAAqIgBAiIAAAAIARgbIAhgxIAIAAIAABWgAgVg8IAIAAQABAPAMAAQAMAAACgPIAIAAQgBAVgVAAQgUAAgBgVg");
	this.shape_15.setTransform(77.2,4.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#1A1E5A").s().p("AgYAmQgGgHAAgKQAAgPANgHQAOgIAZAAIAAgCQAAgagWAAQgMAAgJAHIgDgHQALgHANAAQAeAAAAAiIAAAhQAAALABAJIgIAAIgBgMIAAAAQgEAGgGAEQgIAEgJAAQgMAAgHgHgAgVAUQAAAJAFAFQAFAEAHAAQASAAAHgRIABgFIAAgSIgFAAQgmAAAAAWg");
	this.shape_16.setTransform(68.1,6.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#1A1E5A").s().p("AAWAsIAAglIAAAAQgLAHgNAAQgMAAgHgFQgJgHAAgNIAAggIAJAAIAAAfQAAAUAVAAQAMAAAKgIIAAgrIAJAAIAABXg");
	this.shape_17.setTransform(59.9,6.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#1A1E5A").s().p("AgiA4QAIgDAHgHQAJgJAFgNIABgDIgBgEIgghPIAJAAIAXA4IAFASIABAAIAGgSIAVg4IAKAAIgaA/QgJAWgEALQgHANgIAHQgIAHgIACg");
	this.shape_18.setTransform(51.6,8.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#1A1E5A").s().p("AgjAkIAIgCQAHgFACgLQACgIAAgTIAAghIA0AAIAABVIgIAAIAAhOIgkAAIAAAZQAAAWgCAKQgEAOgIAFQgGACgHAAg");
	this.shape_19.setTransform(42.7,6.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#1A1E5A").s().p("AgcAhQgMgMABgUQAAgVAMgMQAMgMAPAAQASAAALAMQAMAMAAAUQAAAWgOAMQgLALgQAAQgRAAgLgMgAgXgZQgIALAAAOQAAAQAJALQAJALANAAQANAAAKgLQAIgLABgQQgBgNgGgLQgKgNgPAAQgPAAgIAMg");
	this.shape_20.setTransform(34.3,6.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#1A1E5A").s().p("AAgA9IAAhxIhAAAIAABxIgIAAIAAh5IBQAAIAAB5g");
	this.shape_21.setTransform(24,4.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol12, new cjs.Rectangle(0,-5,240,22), null);


(lib.Symbol11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1A1E5A").s().p("AAAAIQgDAAgCgCQgCgDABgDQAAgHAGAAQAHAAAAAHQAAAEgCACQgCACgDAAg");
	this.shape.setTransform(140,34.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1A1E5A").s().p("AgYAmQgGgHAAgKQAAgPANgHQAOgIAZAAIAAgCQAAgagWAAQgMAAgJAHIgDgHQALgHANAAQAeAAAAAiIAAAhQAAALABAJIgIAAIgBgMIAAAAQgEAGgGAEQgIAEgJAAQgMAAgHgHgAgVAUQAAAJAFAFQAFAEAHAAQASAAAHgRIABgFIAAgSIgFAAQgmAAAAAWg");
	this.shape_1.setTransform(133.9,31.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1A1E5A").s().p("AgZAnIADgHQAKAGAKAAQAJAAAFgFQAFgEAAgIQAAgGgFgFQgDgEgJgEQgWgHAAgQQAAgJAHgHQAHgHALAAQAMAAAHAFIgDAHQgHgFgKAAQgHAAgEAFQgFAEAAAGQABAGAEAEQADAEAJAEQAWAHABARQgBALgHAHQgJAHgMAAQgLAAgLgGg");
	this.shape_2.setTransform(126.8,31.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1A1E5A").s().p("AgDA7IAAhVIAHAAIAABVgAgFguQgBgCAAgDQAAgDACgCQACgCACAAQAHAAAAAHQAAAIgHAAQgCAAgDgDg");
	this.shape_3.setTransform(121.6,29.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#1A1E5A").s().p("AgFA9Igph5IAJAAIAWBAQAKAeAEARIAAAAQADgQAMgfIAXhAIAKAAIgtB5g");
	this.shape_4.setTransform(115.2,29.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1A1E5A").s().p("AgVAhQgLgMAAgUQAAgUAMgMQANgNASAAQAPAAAHAFIgCAHQgKgFgLAAQgPAAgKAMQgJAKAAAPQAAARAKALQAJAKAOAAQALAAALgFIACAGQgLAGgOAAQgRAAgMgMg");
	this.shape_5.setTransform(102.7,31.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1A1E5A").s().p("AAlArIgCgsIgCggIgBAAIgKAcIgUAwIgFAAIgTgvIgKgdIAAAAIgCAgIgCAsIgJAAIAHhVIAKAAIATAxIAJAZIAMggIARgqIAKAAIAHBVg");
	this.shape_6.setTransform(185.3,11.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1A1E5A").s().p("AgcAhQgMgMAAgUQAAgVANgMQAMgMAQAAQARAAALAMQAMAMgBAUQAAAWgNAMQgMALgPAAQgRAAgLgMgAgXgZQgIALAAAOQAAAQAJALQAJALANAAQANAAAJgLQAKgLgBgQQABgNgIgLQgIgNgQAAQgPAAgIAMg");
	this.shape_7.setTransform(175.3,11.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1A1E5A").s().p("AAZArIAAgqIgxAAIAAAqIgIAAIAAhVIAIAAIAAAlIAxAAIAAglIAIAAIAABVg");
	this.shape_8.setTransform(165.8,11.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1A1E5A").s().p("AgcAhQgLgMAAgUQAAgVAMgMQALgMAQAAQASAAALAMQAMAMAAAUQAAAWgOAMQgLALgQAAQgRAAgLgMgAgXgZQgIALAAAOQAAAQAJALQAJALANAAQANAAAKgLQAIgLABgQQgBgNgGgLQgKgNgPAAQgOAAgJAMg");
	this.shape_9.setTransform(156.3,11.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1A1E5A").s().p("AgDBSIAAgiQgTgBgMgMQgLgMAAgTQAAgUAMgMQALgMATgBIAAgoIAHAAIAAAoQATABAMAMQALAMAAASQAAAVgMAMQgLAMgTABIAAAigAAEAqQAOgCAKgLQAJgLAAgPQAAgPgJgKQgJgLgPgBgAgbgWQgKALABAOQAAAQAJAKQAKALAOACIAAhMQgPABgJALg");
	this.shape_10.setTransform(146.2,10.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1A1E5A").s().p("AgDArIAAhOIgcAAIAAgHIA/AAIAAAHIgcAAIAABOg");
	this.shape_11.setTransform(137.5,11.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#1A1E5A").s().p("AglA+IAAhdIgBgcIAIAAIAAAQIABAAQAKgSAVAAQAQAAALANQAKALAAAUQAAAVgMAMQgKAMgRAAQgUAAgIgPIgBAAIAAAxgAgQgvQgJAGgCAKIgCAIIAAAQIABAHQACAKAJAFQAHAGAKABQAOAAAIgMQAIgKAAgRQABgPgJgLQgIgLgOAAQgJAAgHAHg");
	this.shape_12.setTransform(129.5,12.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#1A1E5A").s().p("AgYAmQgGgHAAgKQAAgPANgHQAOgIAZAAIAAgCQAAgagWAAQgMAAgJAHIgDgHQALgHANAAQAeAAAAAiIAAAhQAAALABAJIgIAAIgBgMIAAAAQgEAGgGAEQgIAEgJAAQgMAAgHgHgAgVAUQAAAJAFAFQAFAEAHAAQASAAAHgRIABgFIAAgSIgFAAQgmAAAAAWg");
	this.shape_13.setTransform(119.8,11.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#1A1E5A").s().p("AAlArIgCgsIgCggIgBAAIgKAcIgUAwIgFAAIgTgvIgKgdIAAAAIgCAgIgCAsIgJAAIAHhVIAKAAIATAxIAJAZIAMggIARgqIAKAAIAHBVg");
	this.shape_14.setTransform(110.7,11.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#1A1E5A").s().p("AgVAhQgMgMABgUQAAgUAMgMQANgNASAAQAPAAAHAFIgCAHQgJgFgMAAQgPAAgKAMQgJAKAAAPQAAARAKALQAJAKAOAAQALAAALgFIACAGQgLAGgOAAQgSAAgLgMg");
	this.shape_15.setTransform(101.5,11.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#1A1E5A").s().p("AAZArIAAgrIABghIgSAdIgfAvIgJAAIAAhVIAIAAIAAAqIgBAiIABAAIAQgcIAggwIAJAAIAABVg");
	this.shape_16.setTransform(88.8,11.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#1A1E5A").s().p("AgDArIAAhOIgcAAIAAgHIA/AAIAAAHIgcAAIAABOg");
	this.shape_17.setTransform(80.6,11.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#1A1E5A").s().p("AgYAmQgGgHAAgKQAAgPANgHQAOgIAZAAIAAgCQAAgagWAAQgMAAgJAHIgDgHQALgHANAAQAeAAAAAiIAAAhQAAALABAJIgIAAIgBgMIAAAAQgEAGgGAEQgIAEgJAAQgMAAgHgHgAgVAUQAAAJAFAFQAFAEAHAAQASAAAHgRIABgFIAAgSIgFAAQgmAAAAAWg");
	this.shape_18.setTransform(72.9,11.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#1A1E5A").s().p("AgjAkIAIgCQAHgEACgMQACgJAAgRIAAgjIA0AAIAABWIgIAAIAAhOIgkAAIAAAaQAAAUgCALQgEAOgIAEQgGAEgHAAg");
	this.shape_19.setTransform(64.1,11.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#1A1E5A").s().p("AAgA9IAAhxIg/AAIAABxIgJAAIAAh5IBRAAIAAB5g");
	this.shape_20.setTransform(54.9,9.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol11, new cjs.Rectangle(0,0,240,42), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#1E1959","#212297"],[0,1],-31.8,0,31.9,0).s().p("AgKBdIAKgsQAZANAagBQANAAAIgEQALgGAAgJQAAgGgGgGQgGgGgPgHQgtgVAAggQAAgdAYgSQAYgTAnAAQAXAAAZAJIgJAqQgYgLgbACQgKACgGAEQgGAFABAGQAAAIAkAVQAjATABAeQgBAfgYATQgZASgoAAQglgBgUgJgAEPBkIgGgeIhDAAIgKAeIg3AAIBOi3QAGgPAQAAIAsAAIAqDGgADVAeIArAAIgQhLgAhgBkIAqjGIA0AAIgrDGgAjVBkIgpieQgDgHgCgEQgCgDgGgDQgTgLgggGIABgGIBYAAQAUAAAEAUIAWByIA1iGIA2AAIhTDGg");
	this.shape.setTransform(31.9,10.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(0,0,63.7,20.6), null);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1E1B66").s().p("AgCAbIAAgYIgXAAIAAgFIAXAAIAAgXIAFAAIAAAXIAXAAIAAAFIgXAAIAAAYg");
	this.shape.setTransform(15.2,6.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1E1B66").s().p("AgPAcQgGgEAAgIQAAgMANgEQgLgGABgKQAAgHAFgFQAGgEAIgBQAJAAAFAGQAEAEABAGQAAAKgLAGIAAAAQANAEAAAMQAAAIgHAFQgFAFgKABQgJgBgGgFgAgMAPQAAAFAEAEQADADAFAAQAGAAAEgDQADgDAAgFQAAgLgNgEQgMAEAAAKgAgHgXQgDACAAAFQAAAJAMADQAKgDAAgJQgBgEgCgDQgDgDgFAAQgFAAgDADg");
	this.shape_1.setTransform(9.7,6.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E1B66").s().p("AACAhIAAg5IgKAHIgCgHIANgIIAIAAIAABBg");
	this.shape_2.setTransform(4.1,6.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(0,0,20.4,14), null);


(lib.momentum_vert_hvost = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0044AF").s().p("ArmHVIWVv3IA4BPI2VP2g");
	this.shape.setTransform(77.3,26.8,0.49,0.49);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0044AF").s().p("AnzHJIOovNIA/A8IupPNg");
	this.shape_1.setTransform(76.9,34.6,0.49,0.49);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0044AF").s().p("AkAHBIG7ujIBHAiIm9Ojg");
	this.shape_2.setTransform(76.5,42.4,0.49,0.49);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0044AF").s().p("Ag5m7IBDgDIAwN5IhDAEg");
	this.shape_3.setTransform(76,50.2,0.49,0.49);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0044AF").s().p("AkmmYIAygfIIbNQIgyAfg");
	this.shape_4.setTransform(75.6,58,0.49,0.49);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0044AF").s().p("AoSl/IAegnIQHMmIgeAng");
	this.shape_5.setTransform(75.2,65.8,0.49,0.49);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0044AF").s().p("AsClsIASgkIXzL9IgSAkg");
	this.shape_6.setTransform(74.8,73.6,0.49,0.49);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#F4C911","#FA9C01"],[0,1],61,16.7,-60.8,-16.6).s().p("ApniiIACgKITNFOIgDALg");
	this.shape_7.setTransform(73.8,89);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#F4C911","#FA9C01"],[0,1],49.2,17.5,-49.1,-17.4).s().p("AnwiqIAGgOIPaFjIgEANg");
	this.shape_8.setTransform(74.4,81.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#F4C911","#FA9C01"],[0,1],73.2,15.6,-73.3,-15.6).s().p("ArfiaIABgFIW+E5IgBAGg");
	this.shape_9.setTransform(73.6,97);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.momentum_vert_hvost, new cjs.Rectangle(0,0,147.2,113), null);


(lib.Symbol22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Symbol17();
	this.instance.parent = this;
	this.instance.setTransform(150,22,1,1,0,0,0,150,22);
	this.instance.alpha = 0.449;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 1
	this.instance_1 = new lib.Symbol17();
	this.instance_1.parent = this;
	this.instance_1.setTransform(150,22,1,1,0,0,0,150,22);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol22, new cjs.Rectangle(0,0,300,26), null);


(lib.Symbol18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.Symbol28();
	this.instance.parent = this;
	this.instance.setTransform(120,212,1,1,0,0,0,105,112);
	this.instance.cache(-2,0,273,266);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol18, new cjs.Rectangle(15,102,269,262), null);


(lib.Symbol14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol2();
	this.instance.parent = this;
	this.instance.setTransform(25.3,13.3,0.791,0.791,0,0,0,31.9,10.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol14, new cjs.Rectangle(0,5.2,50.4,16.3), null);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Symbol19();
	this.instance.parent = this;
	this.instance.setTransform(150,22,1,1,0,0,0,150,22);
	this.instance.alpha = 0.449;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.Symbol19();
	this.instance_1.parent = this;
	this.instance_1.setTransform(150,22,1,1,0,0,0,150,22);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8, new cjs.Rectangle(0,0,300,26), null);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.mc_hand_initial = new lib.Symbol24hjj();
	this.mc_hand_initial.name = "mc_hand_initial";
	this.mc_hand_initial.parent = this;
	this.mc_hand_initial.setTransform(52.4,352.5,0.664,0.664,-4,0,0,20.3,18.6);

	this.timeline.addTween(cjs.Tween.get(this.mc_hand_initial).wait(1));

	// Layer_2
	this.mc_hand = new lib.Symbol24hjj();
	this.mc_hand.name = "mc_hand";
	this.mc_hand.parent = this;
	this.mc_hand.setTransform(55.2,357.4,0.759,0.759,0,0,0,20.2,18.4);

	this.timeline.addTween(cjs.Tween.get(this.mc_hand).wait(1));

	// Layer_1
	this.instance = new lib._99();
	this.instance.parent = this;
	this.instance.setTransform(-53,67.6,0.722,0.722);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(-53,67.6,318.3,433), null);


(lib.Group = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.6).p("AFfAAQAABqhnBKQhnBLiRAAQiRAAhmhLQhnhKAAhqQAAhpBnhLQBmhKCRAAQCRAABnBKQBnBLAABpg");
	this.shape.setTransform(35.9,26.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgjCsQgFgEAAgHQAAgGAFgFQALgMAMgaQAWg0AAhEQAAhBgVgsIgXgeQgFgEgBgGQAAgHADgFQAEgFAGgBQAHgBAFADIAcAlQAcAzAABNQAABNgbA6QgNAegOAPQgFAFgGAAQgHAAgEgFg");
	this.shape_1.setTransform(43.5,26.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdCNQgFgEAAgHQAAgGAEgFQAJgKAJgVQAQgpAAg1QAAg0gPgiIgRgYQgFgEgBgGQgBgHAEgFQAEgFAGgBQAHgBAFAEIAWAeQAWAqAAA/QAAA+gVAwQgNAdgIAHQgFAFgGAAQgGAAgFgEg");
	this.shape_2.setTransform(36.9,26.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgZBpQgFgFAAgGQAAgHAFgEQAHgIAGgOQAMgcAAglQAAgkgLgXIgMgRQgFgDgBgHQgBgGADgGQAEgFAGgBQAHgBAFAEQAJAGAKASQARAeAAAvQAAAtgRAkQgJASgIAKQgEAEgHAAQgGAAgFgEg");
	this.shape_3.setTransform(29,26.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgSBHQgFgEAAgGQAAgHAEgFIABgCQALgRABgeQgBgfgLgPIgBgDQgEgEAAgHQAAgGAFgFQAFgDAFAAQAHAAAEAEIADAFQASAWAAApIAAAFQAAApgSAWIgDAEQgEAGgHgBQgGABgEgFg");
	this.shape_4.setTransform(22.3,26.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_2
	this.instance = new lib.Symbol23();
	this.instance.parent = this;
	this.instance.setTransform(35.7,28.6,1.354,1,0,0,0,49,49.1);
	this.instance.alpha = 0.34;
	this.instance.cache(-2,-2,102,102);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(-30.7,-20.5,132.6,98.2), null);


(lib.Symbol26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mc_momentum_hvost
	this.mc_momentum_hvost = new lib.momentum_vert_hvost();
	this.mc_momentum_hvost.name = "mc_momentum_hvost";
	this.mc_momentum_hvost.parent = this;
	this.mc_momentum_hvost.setTransform(104.9,420.2,0.8,0.8,0,0,180,73.5,56.8);

	this.timeline.addTween(cjs.Tween.get(this.mc_momentum_hvost).wait(1));

	// mc_momentum_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ApBZ7IALgSIhugyIAMgZIhvgsIAMgdIhugnIALgdIhugkIAMgfIh/gnIAJggIh5glMAAAgz6MAlfAAAMAAAA42IiFgdIgNBHIhxgXIgMBIIkRg/IC6AvIgPBCIoNiCIHDB6IgQA9IrOi9IKBC4IgRA6Iq0jFIJoDDIgRA2Ip8jDIIwDFIgRAyIo2i/IHqDGIgSAtIn2i9IGrDIIgTApImni5IFeDJIgUAkg");
	mask.setTransform(120,204.8);

	// mc_photo
	this.mc_photos = new lib.Symbol3();
	this.mc_photos.name = "mc_photos";
	this.mc_photos.parent = this;
	this.mc_photos.setTransform(139,179.5,1.003,1.003,0,0,0,115.1,219);

	var maskedShapeInstanceList = [this.mc_photos];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.mc_photos).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol26, new cjs.Rectangle(0,27.6,240,437.6), null);


(lib.main = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		
		if(window.hideznak){
			this.mc_ager.visible = false;
		}
		
		var debug = true;
		var R = this;
		
		if(window.disabledebug){
			debug = false;
		}
		
		
		var time_in = 0.75;
		var time_out = 0.6;
		var txt_in = {alpha: 0, ease:Power2.easeOut};
		var txt_out = {alpha: 0, ease:Power1.easeIn};
		
		
		/*
		var pixelRatio = window.devicePixelRatio;
		cached_clips_array = [
			R.txt_white,
			R.txt_gold,
			R.txt_gold_brand,
			R.txt_you,
			R.txt_we,
			R.mc_brand,
			R.mc_ager.mc_digit,
			R.mc_disclaimer
		];
		
		function cachedSwitch(mc){
			if (pixelRatio == 1){
				mc.cache(0,0,640,512)
			}
		}
		var i;
		var a = ["a", "b", "c"];
		for (i = 0; i < cached_clips_array.length; ++i) {
		    //console.log(cached_clips_array[i]);
			cachedSwitch(cached_clips_array[i])
		}
		*/
		
		var inX = R.mc_scene.mc_photos.mc_hand_initial.x;
		var inY = R.mc_scene.mc_photos.mc_hand_initial.y;
		var inSX = R.mc_scene.mc_photos.mc_hand_initial.scaleX;
		var inSY = R.mc_scene.mc_photos.mc_hand_initial.scaleY;
		var inRT = R.mc_scene.mc_photos.mc_hand_initial.rotation;
		
		R.mc_scene.mc_photos.mc_hand_initial.visible = false;
		
		
		var tmax_options = {
			repeat: -1
		}
		
		this.tl = new TimelineMax(tmax_options);
		
		this.tl.to(R.mc_fade, 0.7, {alpha:0, ease: Power1.easeOut}, 0)
		
		.from(R.mc_scene, 0.7, {y:'-=35', ease: Power1.easeOut}, 0)
		
		// FRAME 1
		.add('frame1')
		.from(R.txt_you, time_in, txt_in, 0.15)
		.to(R.txt_you, time_out, txt_out, '+=1.6')
		
		
		.from(R.mc_scene.mc_photos.mc_hand, 0.8, {x:inX, y:inY, rotation:inRT, scaleX:inSX, scaleY:inSY, ease: Power1.easeInOut}, 0.5)
		
		
		
		// FRAME 2
		.add('frame2')
		.from(R.txt_we, time_in, txt_in, '+=0')
		.to(R.txt_we, time_out, txt_out, '+=1.6')
		
		// FRAME 3
		.add('frame3')
		.to(R.mc_scene, 0.75, {y:'-=115', ease: Power1.easeInOut}, 'frame3')
		.to(R.mc_scene.mc_photos, 1.0, {x:'-=2', y:'+=60', scaleX: '-=0.18', scaleY: '-=0.18', ease: Power2.easeInOut}, 'frame3-=0')
		//.from(R.mc_scene.mc_photos.photo2, time_in*1.5, txt_in, 'frame3-=0.1')
		//.to(R.mc_scene.mc_photos.photo1, time_out*1.5, txt_out, 'frame3+=0.2')
		.from(R.txt_3, time_in, txt_in, 'frame3+=0.5')
		
		//.to(R.logo_visa, time_out*1.5, txt_out, 'frame3-=0.3')
		//.from(R.logo_all, time_in*1.5, txt_in, 'frame3+=0.4')
		
		.from(R.mc_face, 0.9, {y:'+=70', alpha:0, ease: Back.easeOut}, 'frame3+=0.5')
		.from(R.mc_waveicon, 0.6, {alpha:0, ease: Power1.easeOut}, 'frame3+=0.9')
		
		.to(R.txt_3, time_out, txt_out, '+=1.6')
		
		
		// FRAME 4
		.add('frame4')
		.from(R.txt_4, time_in, txt_in, '+=0')
		.from(R.btn_cta, 0.7, {scaleX: '-=0.6', scaleY: '-=0.6', alpha:0, ease: Back.easeOut}, '+=0')
		.call(pauseCall)
		
		
		// FRAME 5
		.add('frame5')
		.to(R.mc_fade, 0.7, {alpha:1, ease: Power1.easeInOut}, '+=2.0')
		.from(R.mc_disclaimer, time_in*1.5, txt_in, '+=0.0')
		.to(R.mc_disclaimer, time_out, txt_out, '+=1.6')
		
		//.to(R.mc_scene.mc_photos.photo1, 10, {scaleX: '+=0.1', scaleY: '+=0.1', ease: Power1.easeOut}, 0)
		//.to(R.mc_scene.mc_photos.photo2, 10, {scaleX: '+=0.1', scaleY: '+=0.1', ease: Power1.easeOut}, 'frame3')
		
		
		this.tl.timeScale(1.0);
		
		//this.tl.seek('frame3');
		
		
		function pauseCall(){
			if (this.needtostop){
				R.tl.pause();
				stage.tickEnabled = false;
			} else {
				if(window.animationlimit){
					this.needtostop = true;
				}
			}
		}
		
		if(debug){
			//console.log('timeline total duration: ' + this.tl.duration());
		}
		
		stage.enableMouseOver(); // for button rollover effect
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(30));

	// DISCLAIMER
	this.mc_disclaimer = new lib.Symbol18();
	this.mc_disclaimer.name = "mc_disclaimer";
	this.mc_disclaimer.parent = this;
	this.mc_disclaimer.setTransform(120,113,1,1,0,0,0,120,200);

	this.timeline.addTween(cjs.Tween.get(this.mc_disclaimer).wait(30));

	// AGE
	this.instance = new lib.Symbol1();
	this.instance.parent = this;
	this.instance.setTransform(14,489.5,1,1,0,0,0,11,7.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(30));

	// LOGO_ALL
	this.logo_all = new lib.Symbol14();
	this.logo_all.name = "logo_all";
	this.logo_all.parent = this;
	this.logo_all.setTransform(232.6,460.4,1.559,1.559,0,0,0,25.8,12.6);

	this.timeline.addTween(cjs.Tween.get(this.logo_all).wait(30));

	// FADE
	this.mc_fade = new lib.Symbol16();
	this.mc_fade.name = "mc_fade";
	this.mc_fade.parent = this;
	this.mc_fade.setTransform(120,200,1,1,0,0,0,120,200);

	this.timeline.addTween(cjs.Tween.get(this.mc_fade).wait(30));

	// Layer_5
	this.mc_waveicon = new lib.Group();
	this.mc_waveicon.name = "mc_waveicon";
	this.mc_waveicon.parent = this;
	this.mc_waveicon.setTransform(50.6,102,0.541,0.54,0,0,0,36.2,26.6);
	this.mc_waveicon.shadow = new cjs.Shadow("rgba(19,20,19,0)",0,0,0);

	this.mc_face = new lib.Symbol20();
	this.mc_face.name = "mc_face";
	this.mc_face.parent = this;
	this.mc_face.setTransform(50,188.1,1,1,0,0,0,31,63);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.mc_face},{t:this.mc_waveicon}]}).wait(30));

	// CTA
	this.btn_cta = new lib.Symbol23cta();
	this.btn_cta.name = "btn_cta";
	this.btn_cta.parent = this;
	this.btn_cta.setTransform(151.3,402.4,0.691,0.691,0,0,0,105.5,23.4);
	new cjs.ButtonHelper(this.btn_cta, 0, 1, 2, false, new lib.Symbol23cta(), 3);

	this.timeline.addTween(cjs.Tween.get(this.btn_cta).wait(30));

	// txt 4
	this.txt_4 = new lib.Symbol12();
	this.txt_4.name = "txt_4";
	this.txt_4.parent = this;
	this.txt_4.setTransform(151,380.9,1.192,1.192,0,0,0,120,23.1);

	this.timeline.addTween(cjs.Tween.get(this.txt_4).wait(30));

	// txt 3
	this.txt_3 = new lib.Symbol11();
	this.txt_3.name = "txt_3";
	this.txt_3.parent = this;
	this.txt_3.setTransform(151,391.5,1.192,1.192,0,0,0,120,23);

	this.timeline.addTween(cjs.Tween.get(this.txt_3).wait(30));

	// TEXT WE
	this.txt_we = new lib.Symbol8();
	this.txt_we.name = "txt_we";
	this.txt_we.parent = this;
	this.txt_we.setTransform(169,44,1,1,0,0,0,150,26);

	this.timeline.addTween(cjs.Tween.get(this.txt_we).wait(30));

	// TEXT YOU
	this.txt_you = new lib.Symbol22();
	this.txt_you.name = "txt_you";
	this.txt_you.parent = this;
	this.txt_you.setTransform(94,40,1,1,0,0,0,75,22);

	this.timeline.addTween(cjs.Tween.get(this.txt_you).wait(30));

	// SCENE
	this.mc_scene = new lib.Symbol26();
	this.mc_scene.name = "mc_scene";
	this.mc_scene.parent = this;
	this.mc_scene.setTransform(109.4,149.1,1.25,1.25,0,0,0,87.5,233.6);

	this.timeline.addTween(cjs.Tween.get(this.mc_scene).wait(30));

	// BG
	this.mc_bg = new lib.Symbol16();
	this.mc_bg.name = "mc_bg";
	this.mc_bg.parent = this;
	this.mc_bg.setTransform(120,200,1,1,0,0,0,120,200);
	this.mc_bg.cache(-2,-2,304,504);

	this.timeline.addTween(cjs.Tween.get(this.mc_bg).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-37,-146.1,1661.1,646.1);


// stage content:
(lib._300x500 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var domOverlay = document.getElementById("dom_overlay_container");
		//domOverlay.style.border = '1px solid rgba( 0, 0, 0, 0.25)'; // width solid/dotted/dashed + color 05 = alpha
		domOverlay.style.border = '1px solid #142A8E'; // width solid/dotted/dashed + color 05 = alpha
		domOverlay.style.boxSizing = 'border-box';
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// MAIN
	this.instance = new lib.main();
	this.instance.parent = this;
	this.instance.setTransform(120,200,1,1,0,0,0,120,200);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(113,103.9,399,646.1);
// library properties:
lib.properties = {
	id: '4719221F2E3D42E29F5ABEAA693C04A5',
	width: 300,
	height: 500,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"_99.jpg", id:"_99"},
		{src:"300x500_atlas_P__opt.png", id:"300x500_atlas_P_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['4719221F2E3D42E29F5ABEAA693C04A5'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;